<?php
session_start();

// Jika user menekan tombol "Ya, Logout"
if (isset($_POST['confirm'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

// Jika user menekan tombol "Batal"
if (isset($_POST['cancel'])) {
    // Redirect sesuai role
    if (isset($_SESSION['role'])) {
        switch($_SESSION['role']){
            case 'admin':
                header("Location: dashboard_admin.php");
                break;
            case 'pemilik':
                header("Location: dashboard_pemilik.php");
                break;
            case 'penyewa':
                header("Location: dashboard_penyewa.php");
                break;
            default:
                header("Location: login.php");
        }
    } else {
        header("Location: login.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Konfirmasi Logout</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f4f6f9; display:flex; justify-content:center; align-items:center; height:100vh; }
.confirm-box { background:#fff; padding:30px 40px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.15); text-align:center; }
.confirm-box h2 { margin-bottom:20px; color:#333; }
.confirm-box button { padding:10px 20px; margin:5px; font-size:14px; border:none; border-radius:6px; cursor:pointer; }
.btn-yes { background:#e74c3c; color:white; }
.btn-no { background:#3498db; color:white; }
</style>
</head>
<body>

<div class="confirm-box">
    <h2>Apakah Anda yakin ingin logout?</h2>
    <form method="post">
        <button type="submit" name="confirm" class="btn-yes"><i class="fa fa-sign-out-alt"></i> Ya, Logout</button>
        <button type="submit" name="cancel" class="btn-no"><i class="fa fa-times"></i> Batal</button>
    </form>
</div>

</body>
</html>
