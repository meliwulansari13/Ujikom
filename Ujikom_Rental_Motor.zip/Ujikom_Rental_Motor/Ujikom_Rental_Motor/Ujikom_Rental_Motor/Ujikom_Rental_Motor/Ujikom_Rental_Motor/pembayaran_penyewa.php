<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit;
}
include "koneksi.php";

$penyewa_id = $_SESSION['user_id'];
$motor_id   = isset($_GET['motor_id']) ? intval($_GET['motor_id']) : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal_mulai   = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $tipe_durasi     = $_POST['tipe_durasi'];

    $stmt = $conn->prepare("INSERT INTO sewa (motor_id, penyewa_id, tanggal_mulai, tanggal_selesai, tipe_durasi, status) VALUES (?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("iisss", $motor_id, $penyewa_id, $tanggal_mulai, $tanggal_selesai, $tipe_durasi);
    
    if ($stmt->execute()) {
        echo "<script>alert('Sewa berhasil diajukan, menunggu verifikasi admin.'); window.location='riwayat_sewa.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan sewa!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pembayaran Penyewa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {background-color: #f8f9fa;}
    .form-container {
        max-width: 600px;
        margin: 50px auto;
    }
    .card {border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);}
    .card-header {background-color: #0d6efd; color: #fff; font-weight: bold; font-size: 1.2rem;}
    .btn-primary {background-color: #0d6efd; border: none;}
    .btn-primary:hover {background-color: #0b5ed7;}
</style>
</head>
<body>
<div class="form-container">
    <div class="card">
        <div class="card-header text-center">
            Form Sewa Motor
        </div>
        <div class="card-body">
            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Tanggal Mulai</label>
                    <input type="date" name="tanggal_mulai" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tipe Durasi</label>
                    <select name="tipe_durasi" class="form-select" required>
                        <option value="harian">Harian</option>
                        <option value="mingguan">Mingguan</option>
                        <option value="bulanan">Bulanan</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Ajukan Sewa</button>
                    <a href="sewa_penyewa.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
