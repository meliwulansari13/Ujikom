<?php
session_start();
include "koneksi.php";

// Cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$id_pemilik = $_SESSION['user_id'];
$nama_pemilik = $_SESSION['nama'] ?? 'Pemilik';

// Ambil data motor milik pemilik ini
$sql = "SELECT m.*, 
               CASE 
                   WHEN m.verifikasi = 'pending' THEN 'Menunggu Verifikasi Admin'
                   WHEN m.verifikasi = 'diterima' THEN 'Terverifikasi'
                   WHEN m.verifikasi = 'ditolak' THEN 'Ditolak'
                   ELSE 'Belum Diverifikasi'
               END AS status_verifikasi
        FROM motor m
        WHERE m.pemilik_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_pemilik);
$stmt->execute();
$motors = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Motor Saya - Pemilik</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family:'Segoe UI', sans-serif; background:#f4f6f9; margin:0; }
.sidebar { width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; }
.sidebar h2 { text-align:center; margin-bottom:20px; font-size:18px; color:white; }
.sidebar a { display:block; color:white; padding:10px 20px; text-decoration:none; font-size:14px; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }

.topbar { margin-left:220px; background:#fff; padding:10px 20px; display:flex; justify-content:space-between; align-items:center; box-shadow:0 2px 5px rgba(0,0,0,0.1); }
.topbar h1 { margin:0; font-size:20px; }

.dropdown { position:relative; display:inline-block; }
.dropbtn { background:#2980b9; color:white; border:none; padding:6px 12px; border-radius:6px; cursor:pointer; }
.dropdown-content { display:none; position:absolute; right:0; background:#fff; min-width:150px; box-shadow:0 4px 8px rgba(0,0,0,0.1); z-index:1; border-radius:6px; overflow:hidden; }
.dropdown-content a { color:#333; padding:10px; display:block; text-decoration:none; font-size:14px; }
.dropdown-content a:hover { background:#f4f4f4; }
.show { display:block; }

.main { margin-left:220px; padding:20px; min-height:100vh; }
.grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:20px; }

.card { background:#fff; border-radius:12px; box-shadow:0 3px 10px rgba(0,0,0,0.1); overflow:hidden; transition: transform 0.2s, box-shadow 0.2s; display:flex; flex-direction:column; }
.card:hover { transform:translateY(-4px); box-shadow:0 6px 15px rgba(0,0,0,0.15); }
.card img { width:100%; height:180px; object-fit:cover; }

.card-content { padding:15px; flex:1; display:flex; flex-direction:column; gap:6px; }
.card-content h3 { margin:0; font-size:17px; color:#2c3e50; font-weight:600; }
.card-content p { margin:0; font-size:14px; color:#555; }

.status-badge { display:inline-block; padding:3px 8px; border-radius:6px; font-size:12px; font-weight:600; }
.pending { background:#fff3cd; color:#e67e22; }
.diterima { background:#d4edda; color:#27ae60; }
.ditolak { background:#f8d7da; color:#c0392b; }

.actions { margin-top:auto; display:flex; justify-content:space-between; gap:8px; }
.actions a { flex:1; text-align:center; text-decoration:none; padding:6px 10px; background:#2980b9; color:white; border-radius:6px; font-size:13px; transition:0.2s; }
.actions a:hover { background:#1f6391; }
.actions a.delete { background:#c0392b; }
.actions a.delete:hover { background:#922b21; }

.add-btn { display:inline-block; margin-bottom:20px; padding:8px 15px; background:#27ae60; color:white; border-radius:6px; text-decoration:none; font-size:14px; }
.add-btn:hover { background:#1e8449; }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_pemilik.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="motor_pemilik.php" class="active"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_tersedia_pemilik.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="generate_daftar_motor_disewa_pemilik.php"><i class="fa fa-list"></i> Motor Disewa</a>
    <a href="history_bagi_hasil_pemilik.php"><i class="fa fa-history"></i> Bagi Hasil</a>
    <a href="generate_total_pendapatan_pemilik.php"><i class="fa fa-chart-line"></i> Total Pendapatan</a>
</div>

<!-- Topbar -->
<div class="topbar">
    <h1>Motor Saya</h1>
    <div class="dropdown">
        <button class="dropbtn" onclick="document.getElementById('dropdownMenu').classList.toggle('show');">
            <i class="fa fa-user-circle"></i> <?= htmlspecialchars($nama_pemilik) ?> <i class="fa fa-caret-down"></i>
        </button>
        <div id="dropdownMenu" class="dropdown-content">
            <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="main">
    <p style="text-align:center; margin-bottom:20px;">
    </p>

    <p style="text-align:center;">
        <a href="motor_add_pemilik.php" class="add-btn"><i class="fa fa-plus"></i> Tambah Motor</a>
    </p>

    <?php if($motors->num_rows>0): ?>
    <div class="grid">
        <?php while($row = $motors->fetch_assoc()): ?>
       <div class="card">
    <img src="<?= ($row['photo'] && file_exists('uploads_motor/'.$row['photo'])) ? 'uploads_motor/'.$row['photo'] : 'uploads_motor/default.jpg'; ?>" alt="Motor">
    <div class="card-content">
        <h3><?= htmlspecialchars($row['merk']) ?> (<?= htmlspecialchars($row['tipe_cc']) ?> cc)</h3>
        <p><i class="fa fa-id-card"></i> Plat: <?= htmlspecialchars($row['plat_nomor']) ?></p>
        <p>Status: <span class="status-badge"><?= ucfirst($row['status']) ?></span></p>
        <p>Verifikasi: 
            <span class="status-badge <?= strtolower($row['verifikasi']) ?>">
                <?= $row['status_verifikasi'] ?>
            </span>
        </p>
        <div class="actions">
            <a href="motor_edit_pemilik.php?id=<?= $row['id'] ?>"><i class="fa fa-edit"></i> Edit</a>
            <a href="motor_delete_pemilik.php?id=<?= $row['id'] ?>" class="delete" onclick="return confirm('Yakin ingin hapus?')"><i class="fa fa-trash"></i> Hapus</a>
        </div>
    </div>
</div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <p style="text-align:center; color:#7f8c8d;">Belum ada motor yang terdaftar.</p>
    <?php endif; ?>
</div>

<script>
function toggleDropdown() {
    document.getElementById("dropdownMenu").classList.toggle("show");
}
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (let i = 0; i < dropdowns.length; i++) {
            let openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
