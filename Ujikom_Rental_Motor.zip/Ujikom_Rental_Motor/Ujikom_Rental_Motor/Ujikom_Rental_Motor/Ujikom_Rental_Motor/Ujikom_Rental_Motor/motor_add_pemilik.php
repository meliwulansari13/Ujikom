<?php
session_start();
include "koneksi.php";

// Cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

if (isset($_POST['submit'])) {
    $pemilik_id = $_SESSION['user_id'];
    $merk = $_POST['merk'];
    $tipe_cc = $_POST['tipe_cc'];
    $plat_nomor = strtoupper(trim($_POST['plat_nomor'])); // konsisten huruf kapital
    $status = $_POST['status'];

    // cek apakah plat nomor sudah ada
    $cek = $conn->prepare("SELECT id FROM motor WHERE plat_nomor = ?");
    $cek->bind_param("s", $plat_nomor);
    $cek->execute();
    $cek->store_result();

    if ($cek->num_rows > 0) {
        echo "<script>alert('Plat nomor sudah terdaftar!'); window.history.back();</script>";
        exit;
    }
    $cek->close();

    // Upload Foto Motor
    $photo = null;
    if (!empty($_FILES['photo']['name'])) {
        $photo = time() . "_" . basename($_FILES['photo']['name']);
        move_uploaded_file($_FILES['photo']['tmp_name'], "uploads_motor/" . $photo);
    }

    // Upload Dokumen Kepemilikan (opsional multiple)
    $dokumen_files = [];
    if (!empty($_FILES['dokumen_kepemilikan']['name'][0])) {
        foreach ($_FILES['dokumen_kepemilikan']['name'] as $key => $val) {
            if ($_FILES['dokumen_kepemilikan']['error'][$key] == 0) {
                $file_name = time() . "_" . basename($_FILES['dokumen_kepemilikan']['name'][$key]);
                move_uploaded_file($_FILES['dokumen_kepemilikan']['tmp_name'][$key], "uploads_dokumen/" . $file_name);
                $dokumen_files[] = $file_name;
            }
        }
    }
    $dokumen_json = json_encode($dokumen_files);

    // Simpan ke database (prepared statement)
    $sql = $conn->prepare("INSERT INTO motor 
        (pemilik_id, merk, tipe_cc, plat_nomor, photo, dokumen_kepemilikan, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $sql->bind_param("issssss", $pemilik_id, $merk, $tipe_cc, $plat_nomor, $photo, $dokumen_json, $status);

    if ($sql->execute()) {
        header("Location: motor_pemilik.php");
        exit;
    } else {
        echo "Error: " . $sql->error;
    }
    $sql->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Motor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 40px;
        }
        .container {
            max-width: 550px;
            margin: auto;
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }
        label {
            font-weight: bold;
            margin-top: 12px;
            display: block;
            color: #34495e;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }
        input[type="file"] {
            border: none;
        }
        .btn-group {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        button {
            flex: 1;
            padding: 10px;
            font-size: 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-primary {
            background: #27ae60;
            color: #fff;
            margin-right: 10px;
        }
        .btn-primary:hover {
            background: #219150;
        }
        .btn-secondary {
            background: #e74c3c;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><i class="fa fa-motorcycle"></i> Tambah Motor</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label>Merk</label>
            <input type="text" name="merk" required>

            <label>Tipe CC</label>
            <select name="tipe_cc" required>
                <option value="100">100 cc</option>
                <option value="125">125 cc</option>
                <option value="150">150 cc</option>
            </select>

            <label>Plat Nomor</label>
            <input type="text" name="plat_nomor" required>

            <label>Foto Motor</label>
            <input type="file" name="photo" required>

            <label>Dokumen Kepemilikan </label>
            <input type="file" name="dokumen_kepemilikan[]" multiple>

            <div class="btn-group">
                <button type="submit" name="submit" class="btn-primary"><i class="fa fa-save"></i> Simpan</button>
                <button type="button" class="btn-secondary" onclick="window.location.href='motor_pemilik.php'"><i class="fa fa-times"></i> Batal</button>
            </div>
        </form>
    </div>
</body>
</html>