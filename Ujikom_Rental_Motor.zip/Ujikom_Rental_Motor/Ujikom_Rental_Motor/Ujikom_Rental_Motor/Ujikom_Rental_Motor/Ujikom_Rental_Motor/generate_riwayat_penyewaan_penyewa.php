<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "
SELECT s.id AS sewa_id, m.id AS motor_id, m.merk, m.plat_nomor,
       s.tanggal_mulai, s.tanggal_selesai,
       s.tipe_durasi,
       CASE s.tipe_durasi
           WHEN 'harian' THEN COALESCE(t_harga.tarif_harian,0)
           WHEN 'mingguan' THEN COALESCE(t_harga.tarif_mingguan,0)
           WHEN 'bulanan' THEN COALESCE(t_harga.tarif_bulanan,0)
       END AS harga_satuan,
       GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) AS lama_sewa,
       GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) *
       CASE s.tipe_durasi
           WHEN 'harian' THEN COALESCE(t_harga.tarif_harian,0)
           WHEN 'mingguan' THEN COALESCE(t_harga.tarif_mingguan,0)
           WHEN 'bulanan' THEN COALESCE(t_harga.tarif_bulanan,0)
       END AS total_harga,
       s.status
FROM sewa s
JOIN motor m ON s.motor_id = m.id
LEFT JOIN (
    SELECT motor_id,
           MAX(CASE WHEN jenis='harian' THEN harga END) AS tarif_harian,
           MAX(CASE WHEN jenis='mingguan' THEN harga END) AS tarif_mingguan,
           MAX(CASE WHEN jenis='bulanan' THEN harga END) AS tarif_bulanan
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t_harga ON t_harga.motor_id = m.id
WHERE s.penyewa_id = '$user_id'
ORDER BY s.tanggal_mulai DESC
";

$result = mysqli_query($conn, $sql);

$total_harga_semua = 0;
$total_sewa = 0;
$data = [];
if($result && mysqli_num_rows($result) > 0){
    while($row = mysqli_fetch_assoc($result)){
        $total_harga_semua += $row['total_harga'];
        $total_sewa++;
        $data[] = $row;
    }
}
$rata_rata = ($total_sewa > 0) ? $total_harga_semua / $total_sewa : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Laporan Riwayat Penyewaan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{margin:0;font-family:'Segoe UI', Tahoma, sans-serif;background:#f4f6f9;}
.sidebar { width: 220px; background: #111827; color: #fff; height: 100vh; position: fixed; top: 0; left: 0; display: flex; flex-direction: column; overflow-y: auto; }
.sidebar h2 { text-align: center; padding: 20px; margin: 0; font-size: 18px; background: #1f2937; border-bottom: 2px solid #2563eb; color: #fff; }
.sidebar a { display: block; padding: 10px 20px; color: #cfd8dc; text-decoration: none; font-size: 14px; border-left: 4px solid transparent; transition: 0.3s; }
.sidebar a:hover, .sidebar a.active { background: #1f2937; color: #fff; border-left: 4px solid #2563eb; }
.main{margin-left:220px;padding:20px;}
.table-report { width: 100%; border-collapse: collapse; margin-top: 20px; background:white; border-radius:8px; overflow:hidden; }
.table-report th, .table-report td { border:1px solid #ddd; padding:8px; text-align:center; }
.table-report th { background:#34495e; color:white; }
.table-report tr:nth-child(even){background:#fafafa;}
.table-report tr:hover{background:#f1f1f1;}
.header-laporan { text-align:center; margin-top:20px; }
.header-laporan h2, .header-laporan p { margin:0; }
.summary { margin-top:20px; font-weight:bold; text-align:right; }
.btn-print { margin-bottom:15px; }
@media print {
    body{background:#fff;}
    .sidebar, .btn-print { display:none; }
    .main{margin:0;padding:0;}
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_penyewa.php"><i class="fa fa-motorcycle"></i> Dashboard</a>
    <a href="sewa_penyewa.php"><i class="fa fa-motorcycle"></i> Daftar Motor</a>
    <a href="riwayat_sewa.php" class="active"><i class="fa fa-history"></i> Riwayat Sewa</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
<div class="header-laporan">
    <h2>PT. RENTAL MOTOR MAJU JAYA</h2>
    <p>Laporan Riwayat Penyewaan Anda</p>
    <p>Tanggal Cetak: <?= date('d-m-Y') ?></p>
</div>

<button onclick="window.print()" class="btn btn-primary btn-print"><i class="fa fa-print"></i> Cetak Laporan</button>

<?php if(count($data) > 0): ?>
<table class="table-report">
    <thead>
        <tr>
            <th>No</th>
            <th>Merk / Plat</th>
            <th>ID Sewa</th>
            <th>Tanggal Mulai</th>
            <th>Tanggal Selesai</th>
            <th>Lama Sewa</th>
            <th>Total Harga</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; foreach($data as $row): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['merk'].' ('.$row['plat_nomor'].')') ?></td>
            <td><?= $row['sewa_id'] ?></td>
            <td><?= $row['tanggal_mulai'] ?></td>
            <td><?= $row['tanggal_selesai'] ?></td>
            <td><?= $row['lama_sewa'] ?> hari</td>
            <td>Rp <?= number_format($row['total_harga'],0,',','.') ?></td>
            <td><?= ucfirst($row['status']) ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="summary">
    Total Sewa: <?= $total_sewa ?> | Total Pengeluaran: Rp <?= number_format($total_harga_semua,0,',','.') ?> | Rata-rata: Rp <?= number_format($rata_rata,0,',','.') ?>
</div>

<?php else: ?>
<p style="text-align:center; font-weight:bold;">Belum ada riwayat penyewaan</p>
<?php endif; ?>

</div>
</body>
</html>
