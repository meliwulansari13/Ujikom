<?php
session_start();
include "koneksi.php";

// Cek login & role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$pemilik_id = $_SESSION['user_id'];
$id = $_GET['id'] ?? 0;

// Ambil data motor untuk validasi
$sql = "SELECT * FROM motor WHERE id = $id AND pemilik_id = $pemilik_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Motor tidak ditemukan atau bukan milik Anda.");
}

$motor = $result->fetch_assoc();

// Hapus file terkait (foto & dokumen) jika ada
if (!empty($motor['photo']) && file_exists("uploads_motor/" . $motor['photo'])) {
    unlink("uploads_motor/" . $motor['photo']);
}

if (!empty($motor['dokumen_kepemilikan'])) {
    $dokumen_files = json_decode($motor['dokumen_kepemilikan'], true);
    if ($dokumen_files) {
        foreach ($dokumen_files as $doc) {
            if (file_exists("uploads_dokumen/" . $doc)) {
                unlink("uploads_dokumen/" . $doc);
            }
        }
    }
}

// Hapus dari database
$sql = "DELETE FROM motor WHERE id = $id AND pemilik_id = $pemilik_id";
if ($conn->query($sql)) {
    header("Location: motor_pemilik.php?msg=deleted");
    exit;
} else {
    echo "Error: " . $conn->error;
}