<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil nama admin
$id_admin = $_SESSION['user_id'];
$q_admin = $conn->prepare("SELECT nama FROM users WHERE id=?");
$q_admin->bind_param("i", $id_admin);
$q_admin->execute();
$nama_admin = $q_admin->get_result()->fetch_assoc()['nama'] ?? 'Admin';

// Proses verifikasi dari link (GET)
if (isset($_GET['id'], $_GET['aksi'])) {
    $id = (int)$_GET['id'];
    $aksi = $_GET['aksi'];

    if ($aksi === 'diterima') {
        $sql = "UPDATE motor SET verifikasi='diterima', status='tersedia' WHERE id=?";
    } elseif ($aksi === 'ditolak') {
        $sql = "UPDATE motor SET verifikasi='ditolak', status='ditolak' WHERE id=?";
    } else {
        $sql = "";
    }

    if ($sql) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    header("Location: motor_verifikasi.php");
    exit();
}

// Ambil data motor yang verifikasi pending
$sql = "SELECT m.*, u.nama AS nama_pemilik 
        FROM motor m
        LEFT JOIN users u ON m.pemilik_id = u.id
        WHERE m.verifikasi = 'pending'
        ORDER BY m.id ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Verifikasi Motor</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI', sans-serif; background:#f1f3f6; }

/* Sidebar */
.sidebar {
    width:200px;
    background:#000305ff;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    color:white;
    display:flex;
    flex-direction:column;
    overflow-y:auto;
}
.sidebar h2 {
    text-align:center;
    padding:15px;
    margin:0;
    font-size:18px;
    font-weight:bold;
    background:#1a252f;
    color:#f8f7f5ff;
    letter-spacing:1px;
    border-bottom:2px solid #77aad4ff;
}
.sidebar a {
    display:block;
    padding:10px 15px;
    color:#cfd8dc;
    text-decoration:none;
    font-size:13px;
    border-left:4px solid transparent;
    transition:0.3s;
}
.sidebar a:hover, .sidebar a.active {
    background:#0b0c0cff;
    color:#fff;
    border-left:4px solid #77aad4ff;
}

/* Topbar */
.topbar {
    margin-left:200px;
    background:linear-gradient(90deg, #2980b9, #8e44ad);
    padding:10px 15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    position:sticky;
    top:0;
    z-index:10;
}
.topbar h1 {
    margin:0;
    font-size:20px;
    font-weight:bold;
    letter-spacing:1px;
}

/* Main content */
.main {
    margin-left:200px;
    padding:15px;
}

/* Grid cards motor */
.grid-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    max-width: 1000px;
    margin: auto;
}
.card {
    background:#fff;
    border-radius:12px;
    padding:15px;
    box-shadow:0 4px 12px rgba(0,0,0,0.08);
    text-align:center;
    transition: transform 0.2s, box-shadow 0.2s;
}
.card:hover {
    transform: translateY(-5px);
    box-shadow:0 8px 20px rgba(0,0,0,0.15);
}
.card img {
    width:100%;
    max-width:160px;
    height:auto;
    border-radius:8px;
    margin-bottom:8px;
}
.card-content h3 { margin:4px 0; color:#34495e; font-size:16px; }
.card-content p { margin:2px 0; font-size:13px; color:#7f8c8d; }
.card-actions {
    display:flex;
    justify-content:center;
    gap:8px;
    margin-top:8px;
}
.btn-accept, .btn-reject {
    padding:5px 10px;
    border-radius:6px;
    text-decoration:none;
    font-weight:bold;
    font-size:13px;
}
.btn-accept { background:#27ae60; color:#fff; }
.btn-accept:hover { background:#1f8b4d; }
.btn-reject { background:#e74c3c; color:#fff; }
.btn-reject:hover { background:#c0392b; }

.no-data {
    text-align:center;
    font-size:16px;
    color:#7f8c8d;
    margin-top:20px;
}

@media (max-width:768px) {
    .grid-container { grid-template-columns: repeat(auto-fit, minmax(180px,1fr)); }
    .card img { max-width:140px; }
}

/* Footer */
footer {
    display:flex;
    justify-content:center;
    align-items:center;
    margin-left:200px;
    height:50px;
    background:#f1f3f6;
    color:#555;
    font-size:13px;
}
</style>
</head>
<body>

<div class="sidebar">
  <h2>RENTAL MOTOR</h2>
  <a href="users.php"><i class="fa fa-users"></i> Data User</a>
  <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
  <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
  <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
  <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
  <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
  <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
  <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
  <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
  <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
  <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
  <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
  <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
  <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
  <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
  <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
  <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
  <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>


<div class="topbar">
    <h1>Verifikasi Motor</h1>
    <div style="font-size:14px;">
        Admin: <?= htmlspecialchars($nama_admin); ?> 
        <a href="logout.php" style="color:white; text-decoration:none; font-size:14px; padding:6px 10px; background:rgba(255,255,255,0.2); border-radius:6px; margin-left:10px;">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>
    </div>
</div>

<div class="main">
    <h2>Daftar Motor Menunggu Verifikasi</h2>
    <?php if ($result && $result->num_rows > 0): ?>
    <div class="grid-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="card">
                <img src="<?= !empty($row['photo']) ? 'uploads_motor/' . htmlspecialchars($row['photo']) : 'https://via.placeholder.com/200x120?text=No+Image'; ?>" alt="Foto Motor">
                <div class="card-content">
                    <h3><?= htmlspecialchars($row['merk']); ?></h3>
                    <p>Pemilik: <?= htmlspecialchars($row['nama_pemilik']); ?></p>
                    <p>Plat: <?= htmlspecialchars($row['plat_nomor']); ?></p>
                </div>
                <div class="card-actions">
                    <a href="motor_verifikasi.php?id=<?= $row['id']; ?>&aksi=diterima" class="btn-accept" onclick="return confirm('Terima motor ini?')">Terima</a>
                    <a href="motor_verifikasi.php?id=<?= $row['id']; ?>&aksi=ditolak" class="btn-reject" onclick="return confirm('Tolak motor ini?')">Tolak</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
        <div class="no-data">Tidak ada motor yang menunggu verifikasi.</div>
    <?php endif; ?>
</div>

<footer>
    © <?= date('Y'); ?> Meli Wulansari – Rental Motor
</footer>

</body>
</html>
