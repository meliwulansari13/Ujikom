<?php
session_start();
include "koneksi.php";

// Ambil daftar motor yang belum memiliki tarif sama sekali
$motor = mysqli_query($conn, "
    SELECT * FROM motor 
    WHERE id NOT IN (SELECT DISTINCT motor_id FROM tarif)
    ORDER BY merk, tipe_cc, plat_nomor
");

$motors = mysqli_fetch_all($motor, MYSQLI_ASSOC);
$allTarifFilled = count($motors) === 0; // true kalau semua motor sudah ada tarif

// Proses submit
if (isset($_POST['submit']) && !$allTarifFilled) {
    $motor_id = (int)$_POST['motor_id'];
    $harian   = (int)$_POST['harian'];
    $mingguan = (int)$_POST['mingguan'];
    $bulanan  = (int)$_POST['bulanan'];

    if ($motor_id > 0) {
        $stmt = $conn->prepare("INSERT INTO tarif (motor_id, jenis, harga, status) VALUES (?, ?, ?, 'aktif')");
        if ($stmt) {
            // Insert Harian
            $jenis = 'harian'; $harga = $harian; $stmt->bind_param("isi", $motor_id, $jenis, $harga); $stmt->execute();
            // Insert Mingguan
            $jenis = 'mingguan'; $harga = $mingguan; $stmt->bind_param("isi", $motor_id, $jenis, $harga); $stmt->execute();
            // Insert Bulanan
            $jenis = 'bulanan'; $harga = $bulanan; $stmt->bind_param("isi", $motor_id, $jenis, $harga); $stmt->execute();
            $stmt->close();
        }
        header("Location: tarif.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Tarif Motor</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Segoe UI', Tahoma, sans-serif; background:#f2f3f5; margin:0; padding:0; }
.container { max-width:600px; margin:50px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 4px 8px rgba(0,0,0,0.1);}
h2 { text-align:center; margin-bottom:25px; color:#333;}
label { font-size:14px; font-weight:600; display:block; margin-bottom:6px; color:#444;}
select, input { width:100%; padding:10px; margin-bottom:18px; border:1px solid #ccc; border-radius:8px; font-size:14px;}
.btn { display:inline-block; width:48%; padding:12px; border:none; font-size:15px; border-radius:8px; cursor:pointer; transition:0.3s; text-align:center;}
.btn-save { background:#5c6bc0; color:white;}
.btn-save:hover { background:#3f51b5;}
.btn-back { background:#e0e0e0; color:#333; text-decoration:none;}
.btn-back:hover { background:#bdbdbd;}
.actions { display:flex; justify-content:space-between; gap:4%;}
.info { background:#fff3cd; color:#856404; padding:10px; border-radius:8px; text-align:center; margin-bottom:18px; border:1px solid #ffeeba; }
</style>
</head>
<body>
<div class="container">
    <h2><i class="fa fa-tags"></i> Tambah Tarif Motor</h2>
    <form method="post">
        <label for="motor_id">Motor</label>
        <?php if($allTarifFilled): ?>
            <div class="info">Semua motor sudah ditarif, tidak ada pilihan motor tersedia.</div>
        <?php else: ?>
            <select name="motor_id" id="motor_id" required>
                <option value="">Pilih Motor</option>
                <?php foreach($motors as $m): ?>
                    <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['merk'].' '.$m['tipe_cc'].' / '.$m['plat_nomor']) ?></option>
                <?php endforeach; ?>
            </select>
        <?php endif; ?>

        <label for="harian">Tarif Harian</label>
        <input type="number" name="harian" id="harian" required <?= $allTarifFilled ? 'disabled' : '' ?>>

        <label for="mingguan">Tarif Mingguan</label>
        <input type="number" name="mingguan" id="mingguan" required <?= $allTarifFilled ? 'disabled' : '' ?>>

        <label for="bulanan">Tarif Bulanan</label>
        <input type="number" name="bulanan" id="bulanan" required <?= $allTarifFilled ? 'disabled' : '' ?>>

        <div class="actions">
            <button type="submit" name="submit" class="btn btn-save" <?= $allTarifFilled ? 'disabled' : '' ?>><i class="fa fa-save"></i> Simpan</button>
            <a href="tarif.php" class="btn btn-back"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
    </form>
</div>
</body>
</html>