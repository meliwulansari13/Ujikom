<?php
session_start();
include "koneksi.php";

// Cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$pemilik_id = $_SESSION['user_id'];

// Ambil data history bagi hasil pemilik
$sql = "SELECT h.*, m.merk, m.plat_nomor, s.tanggal_mulai, s.tanggal_selesai
        FROM history_bagi_hasil h
        JOIN motor m ON h.motor_id = m.id
        JOIN sewa s ON h.sewa_id = s.id
        WHERE h.pemilik_id = ?
        ORDER BY h.tanggal DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $pemilik_id);
$stmt->execute();
$result = $stmt->get_result();

// Hitung total keseluruhan untuk pemilik
$totalStmt = $conn->prepare("SELECT SUM(total_pendapatan) AS total, SUM(bagi_pemilik) AS total_pemilik FROM history_bagi_hasil WHERE pemilik_id=?");
$totalStmt->bind_param("i", $pemilik_id);
$totalStmt->execute();
$totalRes = $totalStmt->get_result();
$total = $totalRes->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>History Bagi Hasil - Pemilik</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
body { margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f4f6f9; }
.sidebar { width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; }
.sidebar h2 { text-align:center; margin-bottom:20px; font-size:18px; }
.sidebar a { display:block; color:white; padding:10px 20px; text-decoration:none; font-size:14px; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }
.main { margin-left:220px; padding:20px; min-height:100vh; }
h1 { text-align:center; margin-bottom:30px; color:#34495e; }
table { width:100%; border-collapse:collapse; background:white; border-radius:12px; overflow:hidden; box-shadow:0 3px 12px rgba(0,0,0,0.1); }
th, td { padding:12px; text-align:center; border-bottom:1px solid #eee; }
th { background:#2980b9; color:white; }
tr:nth-child(even) { background:#fafafa; }
tr:hover { background:#f1f1f1; }
.alert-info { border-radius:10px; margin-top:20px; padding:15px; }
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_pemilik.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="motor_pemilik.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_tersedia_pemilik.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="generate_daftar_motor_disewa_pemilik.php"><i class="fa fa-list"></i> Motor Disewa</a>
    <a href="history_bagi_hasil_pemilik.php" class="active"><i class="fa fa-history"></i> Bagi Hasil</a>
    <a href="generate_total_pendapatan_pemilik.php"><i class="fa fa-chart-line"></i> Total Pendapatan</a>
</div>

<div class="main">
    <h1>📊 History Bagi Hasil</h1>

    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle mt-3">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Motor</th>
                    <th>Tanggal Sewa</th>
                    <th>Total Pendapatan</th>
                    <th>Bagi Pemilik</th>
                    <th>Tanggal Catat</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0) { 
                    $no = 1;
                    while($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= htmlspecialchars($row['merk']) ?> (<?= htmlspecialchars($row['plat_nomor']) ?>)</td>
                        <td><?= $row['tanggal_mulai'] ?> s/d <?= $row['tanggal_selesai'] ?></td>
                        <td>Rp <?= number_format($row['total_pendapatan'],0,',','.') ?></td>
                        <td>Rp <?= number_format($row['bagi_pemilik'],0,',','.') ?></td>
                        <td><?= $row['tanggal'] ?></td>
                    </tr>
                <?php } } else { ?>
                    <tr><td colspan="6">Belum ada data bagi hasil untuk Anda.</td></tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- Total Keseluruhan -->
    <div class="alert alert-info">
        <h5>Total Keseluruhan</h5>
        <p><b>Total Pendapatan:</b> Rp <?= number_format($total['total'],0,',','.') ?></p>
        <p><b>Total Pemilik:</b> Rp <?= number_format($total['total_pemilik'],0,',','.') ?></p>
    </div>
</div>

</body>
</html>
