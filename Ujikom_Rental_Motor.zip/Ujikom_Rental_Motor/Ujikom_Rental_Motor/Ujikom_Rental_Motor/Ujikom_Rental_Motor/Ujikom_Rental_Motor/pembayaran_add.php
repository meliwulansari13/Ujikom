<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

$error = "";
$success = "";

// Proses Tambah
if(isset($_POST['submit'])) {
    $sewa_id = $_POST['sewa_id'];
    $jumlah  = $_POST['jumlah'];
    $metode  = $_POST['metode'];

    $sql = "INSERT INTO pembayaran (sewa_id, jumlah, metode) VALUES ('$sewa_id', '$jumlah', '$metode')";
    if(mysqli_query($conn, $sql)) {
        $success = "✅ Pembayaran berhasil ditambahkan.";
    } else {
        $error = "❌ Gagal menambahkan pembayaran: " . mysqli_error($conn);
    }
}

// Ambil daftar sewa aktif
$q_sewa = mysqli_query($conn, "SELECT s.id, u.nama AS penyewa, m.merk, m.tipe_cc
                               FROM sewa s
                               JOIN users u ON s.penyewa_id = u.id
                               JOIN motor m ON s.motor_id = m.id
                               WHERE s.status='aktif'");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Pembayaran</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }
        .container {
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-top: 0;
            color: #333;
        }
        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #7f8c8d;
            text-decoration: none;
            font-size: 14px;
        }
        .back:hover { text-decoration: underline; }
        .form-group { margin-bottom: 15px; }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: border 0.2s;
        }
        .form-group input:focus,
        .form-group select:focus {
            border-color: #3498db;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #2ecc71;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover { background: #27ae60; }
        .alert {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .error { background: #fdecea; color: #e74c3c; }
        .success { background: #e8f9f0; color: #27ae60; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tambah Pembayaran</h2>

        <?php if ($error): ?>
            <div class="alert error"><?= $error; ?></div>
        <?php elseif ($success): ?>
            <div class="alert success"><?= $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <select name="sewa_id" required>
                    <option value="">Pilih Sewa</option>
                    <?php while($s = mysqli_fetch_assoc($q_sewa)): ?>
                        <option value="<?= $s['id'] ?>"><?= $s['penyewa'].' / '.$s['merk'].' '.$s['tipe_cc'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <input type="number" name="jumlah" placeholder="Jumlah Pembayaran" required>
            </div>
            <div class="form-group">
                <select name="metode" required>
                    <option value=""> Pilih Metode </option>
                    <option value="tunai">Tunai</option>
                    <option value="transfer">Transfer</option>
                </select>
            </div>
            <button type="submit" name="submit"><i class="fa fa-save"></i> Simpan</button>
             <a href="pembayaran.php" class="back"><i class="fa fa-arrow-left"></i> Kembali</a>
        </form>
    </div>
</body>
</html>