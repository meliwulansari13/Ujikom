<?php
session_start();
include "koneksi.php";

// Cek login & role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Handle searching
$search = "";
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $sql = "SELECT * FROM users 
            WHERE nama LIKE '%$search%' 
            OR email LIKE '%$search%' 
            OR no_tlpn LIKE '%$search%' 
            OR role LIKE '%$search%' 
            ORDER BY id ASC";
} else {
    $sql = "SELECT * FROM users ORDER BY id ASC";
}
$users = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data User</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            margin:0;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background:#f1f3f6;
        }

        /* SIDEBAR */
        .sidebar {
            width:240px;
            background:#000305ff;
            height:100vh;
            position:fixed;
            top:0; left:0;
            color:white;
            display:flex;
            flex-direction:column;
            overflow-y:auto;
        }
        .sidebar h2 {
            text-align:center;
            padding:20px;
            margin:0;
            font-size:18px;
            background:#1a252f;
            color: #FFFFFF;
            letter-spacing:1px;
            border-bottom:2px solid #77aad4ff;
        }
        .sidebar a {
            display:block;
            padding:14px 20px;
            color:#cfd8dc;
            text-decoration:none;
            font-size:14px;
            border-left:4px solid transparent;
            transition:0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            background:#0b0c0cff;
            color:#fff;
            border-left:4px solid #77aad4ff;
        }

        /* TOPBAR */
        .topbar {
            margin-left:240px;
            background:linear-gradient(90deg,#2980b9,#8e44ad);
            padding:15px 25px;
            display:flex;
            justify-content:space-between;
            align-items:center;
            color:white;
            position:sticky;
            top:0;
            z-index:10;
        }
        .topbar h1 {
            margin:0;
            font-size:20px;
            font-weight:bold;
        }
        .dropbtn {
            background:transparent;
            border:none;
            color:white;
            font-size:14px;
            cursor:pointer;
            padding:8px 12px;
            border-radius:6px;
        }
        .dropbtn:hover { background:rgba(255,255,255,0.1); }
        .dropdown { position:relative; display:inline-block; }
        .dropdown-content {
            display:none;
            position:absolute;
            right:0;
            background:#fff;
            min-width:160px;
            box-shadow:0 8px 16px rgba(0,0,0,0.2);
            border-radius:8px;
            overflow:hidden;
            z-index:99;
        }
        .dropdown-content a {
            color:#333;
            padding:10px 15px;
            text-decoration:none;
            display:block;
            font-size:14px;
        }
        .dropdown-content a:hover { background:#f1f1f1; }
        .show { display:block; }

        /* MAIN */
        .main {
            margin-left:240px;
            padding:25px;
            max-width:calc(100% - 240px);
            overflow-x:auto;
        }

        .actions {
            margin-bottom:15px;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:10px;
        }
        .actions a {
            text-decoration:none;
            padding:8px 14px;
            border-radius:6px;
            font-size:14px;
            font-weight:bold;
            transition:0.3s;
            color:white;
        }
        .btn-add { background:#2ecc71; }
        .btn-add:hover { background:#27ae60; }
        .search-box input {
            padding:7px 12px;
            border:1px solid #ebddddff;
            border-radius:6px;
            font-size:14px;
            width:220px;
        }
        .search-box button {
            padding:7px 12px;
            border:none;
            background:#2980b9;
            color:white;
            border-radius:6px;
            cursor:pointer;
            font-size:14px;
        }
        .search-box button:hover { background:#1f6391; }

        table {
            width:100%;
            border-collapse:collapse;
            background:white;
            border-radius:12px;
            overflow:hidden;
            box-shadow:0 3px 8px rgba(0,0,0,0.1);
            font-size:14px;
        }
        th, td {
            padding:10px 12px;
            text-align:center;
            border-bottom:1px solid #eee;
        }
        th { background:#34495e; color:white; }
        tr:nth-child(even) { background:#fafafa; }
        tr:hover { background:#f1f1f1; }

        .aksi a {
            padding:6px 10px;
            border-radius:5px;
            font-size:12px;
            color:white;
            text-decoration:none;
            margin:0 3px;
        }
        .edit { background:#17a2b8; }
        .hapus { background:#dc3545; }

        /* Responsive */
        @media (max-width:1024px) {
            .sidebar { width:200px; }
            .topbar { margin-left:200px; padding:12px 18px; }
            .main { margin-left:200px; padding:18px; }
            table { font-size:13px; }
            .aksi a { font-size:11px; padding:5px 8px; }
        }
        @media (max-width:768px) {
            .sidebar { width:160px; font-size:13px; }
            .topbar { margin-left:160px; padding:10px 15px; font-size:14px; }
            .main { margin-left:160px; padding:15px; }
            table { font-size:12px; }
            .aksi a { font-size:10px; padding:4px 6px; }
        }
    </style>
</head>
<body>
<!-- Sidebar -->
<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_admin.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="users.php" class="active"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>


    <!-- Topbar -->
    <div class="topbar">
        <h1>Data User</h1>
        <div class="dropdown">
            <button class="dropbtn"><i class="fa fa-user-circle"></i> Admin <i class="fa fa-caret-down"></i></button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>

    <!-- Main -->
    <div class="main">
        <div class="actions">
            <a href="user_add.php" class="btn-add"><i class="fa fa-plus"></i> Tambah User</a>
            <form method="get" class="search-box">
                <input type="text" name="search" placeholder="Cari user..." value="<?= htmlspecialchars($search); ?>">
                <button type="submit"><i class="fa fa-search"></i> Cari</button>
            </form>
        </div>

        <table>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>No Telepon</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
            <?php 
            if ($users->num_rows > 0):
                $i = 1; 
                while($row = $users->fetch_assoc()): 
            ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['nama']; ?></td>
                <td><?= $row['email']; ?></td>
                <td><?= $row['no_tlpn']; ?></td>
                <td><?= ucfirst($row['role']); ?></td>
                <td class="aksi">
                    <a href="user_edit.php?id=<?= $row['id']; ?>" class="edit"><i class="fa fa-edit"></i> Edit</a>
                    <a href="user_delete.php?id=<?= $row['id']; ?>" class="hapus" onclick="return confirm('Yakin hapus user ini?');"><i class="fa fa-trash"></i> Hapus</a>
                </td>
            </tr>
            <?php endwhile; else: ?>
            <tr>
                <td colspan="6">Tidak ada data ditemukan.</td>
            </tr>
            <?php endif; ?>
        </table>
    </div>

    <script>
    // Dropdown toggle
    document.querySelector(".dropbtn").addEventListener("click", function(){
        document.getElementById("dropdownMenu").classList.toggle("show");
    });
    window.onclick = function(e) {
        if (!e.target.matches('.dropbtn') && !e.target.closest('.dropbtn')) {
            let dropdowns = document.getElementsByClassName("dropdown-content");
            for (let i = 0; i < dropdowns.length; i++) {
                dropdowns[i].classList.remove("show");
            }
        }
    }
    </script>
</body>
</html>
