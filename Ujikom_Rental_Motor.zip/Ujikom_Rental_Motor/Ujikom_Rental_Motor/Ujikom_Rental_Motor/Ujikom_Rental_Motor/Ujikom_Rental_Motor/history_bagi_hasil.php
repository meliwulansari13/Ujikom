<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT h.*, u.nama AS pemilik, m.merk, m.plat_nomor
        FROM history_bagi_hasil h
        JOIN users u ON h.pemilik_id = u.id
        JOIN motor m ON h.motor_id = m.id
        ORDER BY h.tanggal DESC";
$result = mysqli_query($conn, $sql);

$total = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT SUM(total_pendapatan) AS total, 
            SUM(bagi_pemilik) AS total_pemilik,
            SUM(bagi_admin) AS total_admin
     FROM history_bagi_hasil"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Halaman Admin - Rental Motor</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, sans-serif;
    background: #f4f6f9;
}

/* Sidebar */
.sidebar {
    width: 240px;
    background: #111827;
    color: white;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    padding-top: 20px;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
    letter-spacing: 1px;
    color: white;
}
.sidebar a {
    display: block;
    color: #cfd8dc;
    padding: 12px 20px;
    text-decoration: none;
    font-size: 14px;
    border-left: 4px solid transparent;
    transition: all 0.3s;
}
.sidebar a:hover,
.sidebar a.active {
    background: #1f2937;
    color: #fff;
    border-left: 4px solid #2563eb;
}

/* Main */
.main {
    margin-left: 240px;
    padding: 20px;
    min-height: 100vh;
}

/* Card */
.card {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05);
}
th, td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid #eee;
}
th {
    background: #34495e;
    color: #fff;
}
tr:nth-child(even) {
    background: #fafafa;
}
tr:hover {
    background: #f1f1f1;
}

/* Tombol cetak */
.btn-print {
    display: inline-block;
    padding: 8px 14px;
    background: #27ae60;
    color: white;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
    margin-bottom: 15px;
    border: none;
    cursor: pointer;
}
.btn-print:hover {
    background: #1f8b4d;
}

/* Print mode */
@media print {
    .sidebar, .btn-print { display: none; }
    .main { margin: 0; padding: 0; }
    .card { box-shadow: none; border: none; padding: 0; }
    th, td { border: 1px solid #000; }
    th { background: #ddd; color: #000; }
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-undo"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php" class="active"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>
<div class="main">
    <div class="card">
        <h3 class="mb-3 text-center">📊 Riwayat Bagi Hasil</h3>

        <!-- Tombol Cetak -->
        <button class="btn-print" onclick="window.print()"><i class="fa fa-print"></i> Cetak</button>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Pemilik</th>
                        <th>Motor</th>
                        <th>Total Pendapatan</th>
                        <th>Bagi Pemilik</th>
                        <th>Bagi Admin</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    while($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['pemilik']) ?></td>
                        <td><?= htmlspecialchars($row['merk']) ?> (<?= htmlspecialchars($row['plat_nomor']) ?>)</td>
                        <td>Rp <?= number_format($row['total_pendapatan'],0,',','.') ?></td>
                        <td>Rp <?= number_format($row['bagi_pemilik'],0,',','.') ?></td>
                        <td>Rp <?= number_format($row['bagi_admin'],0,',','.') ?></td>
                        <td><?= $row['tanggal'] ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <h5 class="mt-4">Total Keseluruhan</h5>
        <ul>
            <li><b>Total Pendapatan:</b> Rp <?= number_format($total['total'],0,',','.') ?></li>
            <li><b>Total Pemilik:</b> Rp <?= number_format($total['total_pemilik'],0,',','.') ?></li>
            <li><b>Total Admin:</b> Rp <?= number_format($total['total_admin'],0,',','.') ?></li>
        </ul>
    </div>
</div>

</body>
</html>
