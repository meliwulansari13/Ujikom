<?php
session_start();
include "koneksi.php";

// Cek login admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$user = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $no_tlpn = $_POST['no_tlpn'];
    $role = $_POST['role'];

    // Jika password diisi, update juga
    if (!empty($_POST['password'])) {
        $password = md5($_POST['password']);
        $sql = "UPDATE users SET nama='$nama', email='$email', no_tlpn='$no_tlpn', role='$role', password='$password' WHERE id=$id";
    } else {
        $sql = "UPDATE users SET nama='$nama', email='$email', no_tlpn='$no_tlpn', role='$role' WHERE id=$id";
    }

    $conn->query($sql);
    header("Location: users.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }
        .container {
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-top: 0;
            color: #333;
        }
        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #7f8c8d;
            text-decoration: none;
            font-size: 14px;
        }
        .back:hover {
            text-decoration: underline;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: border 0.2s;
        }
        .form-group input:focus,
        .form-group select:focus {
            border-color: #f39c12;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #e67e22;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #d35400;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="users.php" class="back"><i class="fa fa-arrow-left"></i> Kembali</a>
        <h2>Edit User</h2>
        <form method="POST">
            <div class="form-group">
                <input type="text" name="nama" value="<?= $user['nama']; ?>" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" value="<?= $user['email']; ?>" required>
            </div>
            <div class="form-group">
                <input type="text" name="no_tlpn" value="<?= $user['no_tlpn']; ?>">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password">
            </div>
            <div class="form-group">
                <select name="role" required>
                    <option value="pemilik" <?= $user['role']=='pemilik'?'selected':''; ?>>Pemilik</option>
                    <option value="penyewa" <?= $user['role']=='penyewa'?'selected':''; ?>>Penyewa</option>
                    <option value="admin" <?= $user['role']=='admin'?'selected':''; ?>>Admin</option>
                </select>
            </div>
            <button type="submit" name="update"><i class="fa fa-save"></i> Update</button>
        </form>
    </div>
</body>
</html>
