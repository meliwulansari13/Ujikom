<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id_admin = $_SESSION['user_id'];

// Ambil nama admin
$q_admin = $conn->prepare("SELECT nama FROM users WHERE id=?");
$q_admin->bind_param("i", $id_admin);
$q_admin->execute();
$nama_admin = $q_admin->get_result()->fetch_assoc()['nama'] ?? 'Admin';

// Fungsi hitung jumlah baris tabel
function getCount($conn, $table) {
    $check = $conn->query("SHOW TABLES LIKE '$table'");
    if ($check && $check->num_rows > 0) {
        $result = $conn->query("SELECT COUNT(*) AS jml FROM $table");
        return (int)($result->fetch_assoc()['jml'] ?? 0);
    }
    return 0;
}

// Ambil jumlah data
$total_users     = getCount($conn, "users");
$total_motor     = getCount($conn, "motor");
$total_tarif     = getCount($conn, "tarif");
$total_penyewaan = getCount($conn, "sewa");

// Grafik: default bulanan
$periode = $_GET['periode'] ?? 'bulan';

// Array data grafik
$labels = [];
$sewa_count = [];
$pendapatan_count = [];
$motor_disewa_count = [];
$total_motor_count = [];

// Fungsi bantu hitung data
function hitungDataGrafik($conn, $start, $end, $format='Y-m') {
    $label = date($format, strtotime($start));
    // Jumlah penyewaan
    $res1 = $conn->query("SELECT COUNT(*) AS jml FROM sewa WHERE tanggal_mulai BETWEEN '$start' AND '$end'");
    $sewa = (int)($res1->fetch_assoc()['jml'] ?? 0);
    
    // Pendapatan
    $res2 = $conn->query("
        SELECT SUM((DATEDIFF(s.tanggal_selesai,s.tanggal_mulai)+1) * COALESCE(t.harga,m.harga_sewa,0)) AS total
        FROM sewa s
        JOIN motor m ON s.motor_id=m.id
        LEFT JOIN (
            SELECT motor_id, MAX(harga) AS harga
            FROM tarif
            WHERE status='aktif'
            GROUP BY motor_id
        ) t ON t.motor_id=m.id
        WHERE s.tanggal_mulai BETWEEN '$start' AND '$end' AND s.tanggal_selesai IS NOT NULL
    ");
    $pendapatan = (float)($res2->fetch_assoc()['total'] ?? 0);

    // Motor disewa
    $res3 = $conn->query("SELECT COUNT(*) AS jml FROM motor WHERE status='disewa'");
    $motor_disewa = (int)($res3->fetch_assoc()['jml'] ?? 0);

    // Total motor
    $res4 = $conn->query("SELECT COUNT(*) AS jml FROM motor");
    $total_motor = (int)($res4->fetch_assoc()['jml'] ?? 0);

    return [$label, $sewa, $pendapatan, $motor_disewa, $total_motor];
}

// Generate data sesuai periode
switch($periode){
    case 'hari':
        for($i=6;$i>=0;$i--){
            $day = date('Y-m-d', strtotime("-$i days"));
            [$label,$sewa,$pendapatan,$motor_disewa,$total_motor] = hitungDataGrafik($conn,$day,$day,'d M');
            $labels[] = $label;
            $sewa_count[] = $sewa;
            $pendapatan_count[] = $pendapatan;
            $motor_disewa_count[] = $motor_disewa;
            $total_motor_count[] = $total_motor;
        }
        break;
    case 'minggu':
        for($i=11;$i>=0;$i--){
            $start = date('Y-m-d', strtotime("-$i week Monday"));
            $end = date('Y-m-d', strtotime("-$i week Sunday"));
            [$label,$sewa,$pendapatan,$motor_disewa,$total_motor] = hitungDataGrafik($conn,$start,$end,'d M');
            $labels[] = $label;
            $sewa_count[] = $sewa;
            $pendapatan_count[] = $pendapatan;
            $motor_disewa_count[] = $motor_disewa;
            $total_motor_count[] = $total_motor;
        }
        break;
    case 'tahun':
        for($i=5;$i>=0;$i--){
            $year = date('Y', strtotime("-$i year"));
            $start = "$year-01-01";
            $end = "$year-12-31";
            [$label,$sewa,$pendapatan,$motor_disewa,$total_motor] = hitungDataGrafik($conn,$start,$end,'Y');
            $labels[] = $label;
            $sewa_count[] = $sewa;
            $pendapatan_count[] = $pendapatan;
            $motor_disewa_count[] = $motor_disewa;
            $total_motor_count[] = $total_motor;
        }
        break;
    default: // bulan
        for($i=11;$i>=0;$i--){
            $month = date('Y-m', strtotime("-$i month"));
            $start = date('Y-m-01', strtotime($month));
            $end = date('Y-m-t', strtotime($month));
            [$label,$sewa,$pendapatan,$motor_disewa,$total_motor] = hitungDataGrafik($conn,$start,$end,'M Y');
            $labels[] = $label;
            $sewa_count[] = $sewa;
            $pendapatan_count[] = $pendapatan;
            $motor_disewa_count[] = $motor_disewa;
            $total_motor_count[] = $total_motor;
        }
        break;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* Body */
body { margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f1f3f6; }

/* Sidebar */
.sidebar {
    width:200px; /* lebih ramping */
    background:#000305ff;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    color:white;
    display:flex;
    flex-direction:column;
    overflow-y:auto; /* scroll jika menu banyak */
}
.sidebar h2 {
    text-align:center;
    padding:15px;
    margin:0;
    font-size:18px;
    font-weight:bold;
    background:#1a252f;
    color:#f8f7f5ff;
    letter-spacing:1px;
    border-bottom:2px solid #77aad4ff;
}
.sidebar a {
    display:block;
    padding:10px 15px;
    color:#cfd8dc;
    text-decoration:none;
    font-size:13px;
    border-left:4px solid transparent;
    transition:0.3s;
}
.sidebar a:hover, .sidebar a.active {
    background:#0b0c0cff;
    color:#fff;
    border-left:4px solid #77aad4ff;
}

/* Topbar */
.topbar {
    margin-left:200px; /* menyesuaikan sidebar */
    background:linear-gradient(90deg, #2980b9, #8e44ad);
    padding:10px 15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    position:sticky;
    top:0;
    z-index:10;
}
.topbar h1 {
    margin:0;
    font-size:20px;
    font-weight:bold;
    letter-spacing:1px;
}

/* Main container */
.main {
    margin-left:200px; /* menyesuaikan sidebar */
    padding:15px;
}

/* Card grid */
.cards-pull {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(120px,1fr)); /* card lebih kecil */
    gap:12px;
}

/* Card individual */
.card-pull {
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    background:#fff;
    border-radius:12px;
    padding:15px 10px;
    text-decoration:none;
    color:#2c3e50;
    box-shadow:0 3px 8px rgba(0,0,0,0.08);
    transition:0.3s;
    text-align:center;
}
.card-pull:hover {
    transform: translateY(-3px);
    box-shadow:0 6px 12px rgba(0,0,0,0.12);
}
.card-pull .icon {
    font-size:28px; /* lebih kecil */
    width:45px;
    height:45px;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#fff;
    margin-bottom:8px;
}
.icon.blue { background:#3498db; }
.icon.green { background:#2ecc71; }
.icon.orange { background:#e67e22; }
.icon.purple { background:#9b59b6; }
.icon.red { background:#e74c3c; }
.icon.dark { background:#1b753e; }
.card-pull h3 {
    margin:4px 0;
    font-size:16px;
    font-weight:bold;
}
.card-pull p {
    margin:0;
    font-size:11px;
    color:#7f8c8d;
}

/* Chart */
.chart-container {
    margin:20px 0;
    background:white;
    padding:15px;
    border-radius:12px;
    box-shadow:0 3px 8px rgba(0,0,0,0.08);
}

/* Footer */
footer {
    display:flex;
    justify-content:center;
    align-items:center;
    margin-left:200px;
    height:50px;
    background:#f1f3f6;
    color:#555;
    font-size:13px;
}
</style>

</head>
<body>

<div class="sidebar">
<h2>RENTAL MOTOR</h2>
<a href="users.php"><i class="fa fa-users"></i> Data User</a>
<a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
<a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
<a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
<a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
<a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
<a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
<a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
<a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
<a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
<a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
<a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
<a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
<a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
<a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
<a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
<a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
</div>


<div class="topbar">
<h1>Dashboard Admin</h1>
<div style="font-size:14px; color:white;">
    Admin: <?= htmlspecialchars($nama_admin); ?> 
    <a href="logout.php" style="color:white; text-decoration:none; font-size:14px; padding:6px 10px; background:rgba(255,255,255,0.2); border-radius:6px; margin-left:10px;">
        <i class="fa fa-sign-out-alt"></i> Logout
    </a>
</div>
</div>

<div class="main" style="margin-left:230px; padding:20px;">
<div class="cards-pull">
    <a href="users.php" class="card-pull">
        <div class="icon blue"><i class="fa fa-users"></i></div>
        <h3><?= $total_users ?></h3>
        <p>Total User</p>
    </a>

    <a href="motor_verifikasi.php" class="card-pull">
        <div class="icon orange"><i class="fa fa-hourglass-half"></i></div>
        <h3><?= getCount($conn,'motor',"status='menunggu'") ?></h3>
        <p>Menunggu Verifikasi</p>
    </a>

    <a href="motor.php" class="card-pull">
        <div class="icon green"><i class="fa fa-motorcycle"></i></div>
        <h3><?= $total_motor ?></h3>
        <p>Total Motor</p>
    </a>

    <a href="tarif.php" class="card-pull">
        <div class="icon purple"><i class="fa fa-tags"></i></div>
        <h3><?= $total_tarif ?></h3>
        <p>Tarif Rental</p>
    </a>

    <a href="sewa.php" class="card-pull">
        <div class="icon dark"><i class="fa fa-file-contract"></i></div>
        <h3><?= $total_penyewaan ?></h3>
        <p>Penyewaan Aktif</p>
    </a>

    <a href="pembayaran.php" class="card-pull">
        <div class="icon blue"><i class="fa fa-credit-card"></i></div>
        <h3><?= getCount($conn,'pembayaran') ?></h3>
        <p>Total Pembayaran</p>
    </a>

    <a href="motor_tersedia.php" class="card-pull">
        <div class="icon green"><i class="fa fa-motorcycle"></i></div>
        <h3><?= getCount($conn,'motor',"status='tersedia'") ?></h3>
        <p>Motor Tersedia</p>
    </a>

    <a href="motor.php" class="card-pull">
        <div class="icon orange"><i class="fa fa-motorcycle"></i></div>
        <h3><?= getCount($conn,'motor',"status='disewa'") ?></h3>
        <p>Motor Disewa</p>
    </a>

    <a href="konfirmasi_pembayaran_motor.php" class="card-pull">
        <div class="icon red"><i class="fa fa-hourglass-half"></i></div>
        <h3><?= getCount($conn,'pembayaran',"status='pending'") ?></h3>
        <p>Pembayaran Pending</p>
    </a>

    <a href="konfirmasi_pengembalian.php" class="card-pull">
        <div class="icon red"><i class="fa fa-undo-alt"></i></div>
        <h3><?= getCount($conn,'sewa',"status='dikembalikan_pending'") ?></h3>
        <p>Konfirmasi Pengembalian</p>
    </a>

    <a href="profile.php" class="card-pull">
        <div class="icon purple"><i class="fa fa-user-circle"></i></div>
        <h3>Profil</h3>
        <p>Admin</p>
    </a>

    <a href="generate_Laporan_pembayaran.php" class="card-pull">
        <div class="icon orange"><i class="fa fa-file-invoice"></i></div>
        <h3>Lihat</h3>
        <p>Laporan Pembayaran</p>
    </a>
</div>


<div class="chart-container">
<h3>Grafik Penyewaan & Pendapatan 12 Bulan Terakhir</h3>
<canvas id="chartDashboard"></canvas>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- Footer -->
<footer>
    © <?= date('Y'); ?> Meli Wulansari – Rental Motor
</footer>

<script>
const ctx = document.getElementById('chartDashboard').getContext('2d');
const chart = new Chart(ctx, {
    type:'line',
    data:{
        labels: <?= json_encode($labels) ?>,
        datasets:[
            { label:'Jumlah Penyewaan', data:<?= json_encode($sewa_count) ?>, borderColor:'rgba(52, 152, 219, 1)', backgroundColor:'rgba(52, 152, 219,0.2)', fill:true, tension:0.3 },
            { label:'Pendapatan (Rp)', data:<?= json_encode($pendapatan_count) ?>, borderColor:'rgba(39, 174, 96,1)', backgroundColor:'rgba(39,174,96,0.2)', fill:true, tension:0.3 },
            { label:'Motor Disewa', data:<?= json_encode($motor_disewa_count) ?>, borderColor:'rgba(231, 76, 60,1)', backgroundColor:'rgba(231,76,60,0.2)', fill:true, tension:0.3 },
            { label:'Total Motor', data:<?= json_encode($total_motor_count) ?>, borderColor:'rgba(155, 89, 182,1)', backgroundColor:'rgba(155,89,182,0.2)', fill:true, tension:0.3 }
        ]
    },
    options:{
        responsive:true,
        plugins:{ legend:{ position:'top' }, tooltip:{ mode:'index', intersect:false } },
        scales:{ x:{ title:{ display:true, text:'Periode' } }, y:{ beginAtZero:true, title:{ display:true, text:'Jumlah / Pendapatan' } } }
    }
});

</script>
</body>
</html>
