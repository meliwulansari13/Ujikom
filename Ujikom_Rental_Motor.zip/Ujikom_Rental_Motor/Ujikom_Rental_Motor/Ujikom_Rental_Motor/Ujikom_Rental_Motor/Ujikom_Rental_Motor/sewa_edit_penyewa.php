<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php"); exit;
}
include "koneksi.php";

$id = $_GET['id'];
$id_penyewa = $_SESSION['user_id'];
$sewa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM sewa WHERE id='$id' AND penyewa_id='$id_penyewa'"));
if (!$sewa) die("Data tidak ditemukan!");

if (isset($_POST['submit'])) {
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tipe_durasi = $_POST['tipe_durasi'];

    if ($tipe_durasi=='harian') $tanggal_selesai=date('Y-m-d',strtotime($tanggal_mulai.' +1 day'));
    elseif ($tipe_durasi=='mingguan') $tanggal_selesai=date('Y-m-d',strtotime($tanggal_mulai.' +7 day'));
    else $tanggal_selesai=date('Y-m-d',strtotime($tanggal_mulai.' +30 day'));

    $t = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tarif WHERE motor_id='{$sewa['motor_id']}'"));
    if ($tipe_durasi=='harian') $total=$t['tarif_harian'];
    elseif ($tipe_durasi=='mingguan') $total=$t['tarif_mingguan'];
    else $total=$t['tarif_bulanan'];

    $sql = "UPDATE sewa SET tanggal_mulai='$tanggal_mulai', tanggal_selesai='$tanggal_selesai', tipe_durasi='$tipe_durasi', total_harga='$total' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        header("Location: sewa_penyewa.php"); exit;
    } else echo "Error: ".mysqli_error($conn);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Sewa</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
    body { font-family:'Segoe UI',sans-serif;background:#f2f3f5;margin:0;padding:0; }
    .container { max-width:600px;margin:50px auto;background:#fff;padding:25px;border-radius:12px;box-shadow:0 4px 8px rgba(0,0,0,0.1); }
    h2 { text-align:center;margin-bottom:25px;color:#333; }
    label { font-size:14px;font-weight:600;display:block;margin-bottom:6px;color:#444; }
    input,select { width:100%;padding:10px;margin-bottom:18px;border:1px solid #ccc;border-radius:8px;font-size:14px; }
    .btn { width:48%;padding:12px;border:none;font-size:15px;border-radius:8px;cursor:pointer;transition:0.3s;text-align:center; }
    .btn-save { background:#43a047;color:white; }
    .btn-save:hover { background:#2e7d32; }
    .btn-back { background:#e0e0e0;color:#333;text-decoration:none; }
    .btn-back:hover { background:#bdbdbd; }
    .actions { display:flex;justify-content:space-between;gap:4%; }
</style>
</head>
<body>
<div class="container">
    <h2><i class="fa fa-edit"></i> Edit Sewa</h2>
    <form method="post">
        <label>Tanggal Mulai</label>
        <input type="date" name="tanggal_mulai" value="<?= $sewa['tanggal_mulai'] ?>" required>
        <label>Durasi</label>
        <select name="tipe_durasi" required>
            <option value="harian" <?= $sewa['tipe_durasi']=='harian'?'selected':'' ?>>Harian</option>
            <option value="mingguan" <?= $sewa['tipe_durasi']=='mingguan'?'selected':'' ?>>Mingguan</option>
            <option value="bulanan" <?= $sewa['tipe_durasi']=='bulanan'?'selected':'' ?>>Bulanan</option>
        </select>
        <div class="actions">
            <button type="submit" name="submit" class="btn btn-save"><i class="fa fa-save"></i> Update</button>
            <a href="sewa_penyewa.php" class="btn btn-back"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
    </form>
</div>
</body>
</html>