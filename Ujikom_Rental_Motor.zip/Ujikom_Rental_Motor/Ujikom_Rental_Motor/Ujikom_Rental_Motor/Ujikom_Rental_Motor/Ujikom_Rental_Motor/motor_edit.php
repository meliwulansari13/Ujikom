<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil ID motor
$id = $_GET['id'] ?? 0;

// Ambil data motor
$sql = "SELECT * FROM motor WHERE id=$id";
$result = $conn->query($sql);
$motor = $result->fetch_assoc();

if (!$motor) {
    die("Motor tidak ditemukan!");
}

// Proses update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $merk = $_POST['merk'];
    $tipe_cc = $_POST['tipe_cc'];
    $plat_nomor = $_POST['plat_nomor'];
    $status = $_POST['status'];

    // Upload foto jika ada
    $photo = $motor['photo'];
    if (!empty($_FILES['photo']['name'])) {
        $photo = time() . "_" . $_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'], "uploads_motor/" . $photo);
    }

    // Upload dokumen baru (jika ada)
    $dokumen = json_decode($motor['dokumen_kepemilikan'], true) ?: [];
    if (!empty($_FILES['dokumen']['name'][0])) {
        foreach ($_FILES['dokumen']['name'] as $key => $name) {
            $filename = time() . "_" . $name;
            move_uploaded_file($_FILES['dokumen']['tmp_name'][$key], "uploads_dokumen/" . $filename);
            $dokumen[] = $filename;
        }
    }
    $dokumen_json = json_encode($dokumen);

    $sql = "UPDATE motor SET merk='$merk', tipe_cc='$tipe_cc', plat_nomor='$plat_nomor',
            photo='$photo', dokumen_kepemilikan='$dokumen_json', status='$status'
            WHERE id=$id";

    if ($conn->query($sql)) {
        header("Location: motor.php");
        exit();
    } else {
        echo "Gagal update: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Motor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background:#f0f2f5;
            padding:20px;
        }
        .container {
            max-width:500px;
            margin:auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 2px 6px rgba(0,0,0,0.15);
        }
        h2 {
            text-align:center;
            margin-bottom:20px;
            color:#333;
        }
        label {
            font-weight:bold;
            display:block;
            margin-bottom:5px;
            color:#444;
        }
        input, select {
            width:100%;
            padding:10px;
            margin-bottom:15px;
            border:1px solid #ccc;
            border-radius:6px;
            font-size:14px;
        }
        button {
            width:100%;
            padding:10px;
            background:#007bff;
            border:none;
            border-radius:6px;
            color:white;
            font-size:16px;
            cursor:pointer;
        }
        button:hover {
            background:#0056b3;
        }
        .back {
            display:block;
            text-align:center;
            margin-top:10px;
            text-decoration:none;
            color:#555;
        }
        .preview {
            margin-bottom:15px;
            text-align:center;
        }
        .preview img {
            max-width:120px;
            border-radius:6px;
            box-shadow:0 0 6px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>✏️ Edit Motor</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label>Merk:</label>
            <input type="text" name="merk" value="<?= $motor['merk']; ?>" required>

            <label>Tipe CC:</label>
            <input type="number" name="tipe_cc" value="<?= $motor['tipe_cc']; ?>" required>

            <label>Plat Nomor:</label>
            <input type="text" name="plat_nomor" value="<?= $motor['plat_nomor']; ?>" required>

            <label>Status:</label>
            <select name="status">
                <option value="tersedia" <?= $motor['status']=="tersedia"?"selected":""; ?>>Tersedia</option>
                <option value="disewa" <?= $motor['status']=="disewa"?"selected":""; ?>>Disewa</option>
            </select>

            <label>Foto:</label>
            <div class="preview">
                <?php if ($motor['photo']): ?>
                    <img src="uploads_motor/<?= $motor['photo']; ?>" alt="Foto Motor">
                <?php endif; ?>
            </div>
            <input type="file" name="photo">

            <label>Dokumen:</label>
            <input type="file" name="dokumen[]" multiple>

            <button type="submit">💾 Simpan Perubahan</button>
            <a href="motor.php" class="back">⬅ Batal </a>
        </form>
    </div>
</body>
</html>