<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = intval($_GET['id'] ?? 0);

// Ambil data dulu
$stmt = $conn->prepare("SELECT * FROM motor WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$motor = $result->fetch_assoc();

if ($motor) {
    // Hapus foto jika ada
    if (!empty($motor['photo']) && file_exists("uploads_motor/" . $motor['photo'])) {
        unlink("uploads_motor/" . $motor['photo']);
    }

    // Hapus dokumen jika ada
    $dokumen = json_decode($motor['dokumen_kepemilikan'], true);
    if ($dokumen) {
        foreach ($dokumen as $file) {
            $path = "uploads_dokumen/" . $file;
            if (file_exists($path)) {
                unlink($path);
            }
        }
    }

    // Hapus dari database
    $del = $conn->prepare("DELETE FROM motor WHERE id=?");
    $del->bind_param("i", $id);
    $del->execute();
}

echo "<script>
    alert('✅ Data motor berhasil dihapus!');
    window.location='motor.php';
</script>";
exit();
?>