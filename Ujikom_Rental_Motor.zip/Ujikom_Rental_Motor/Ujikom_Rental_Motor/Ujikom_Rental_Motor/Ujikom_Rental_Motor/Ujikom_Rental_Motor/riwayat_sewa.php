<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit;
}
include "koneksi.php";

$penyewa_id = $_SESSION['user_id'];

// Ambil data sewa milik penyewa
$sql = "SELECT s.id, m.merk, m.plat_nomor, s.tanggal_mulai, s.tanggal_selesai, 
               s.tipe_durasi, s.status
        FROM sewa s
        JOIN motor m ON s.motor_id = m.id
        WHERE s.penyewa_id = ?
        ORDER BY s.id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $penyewa_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Riwayat Sewa - Penyewa</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { background:#f4f6f9; font-family:'Segoe UI', sans-serif; margin:0; }
.sidebar { width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; }
.sidebar h2 { text-align:center; margin-bottom:20px; font-size:18px; color:white; }
.sidebar a { display:block; color:white; padding:10px 20px; text-decoration:none; font-size:14px; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }
.main { margin-left:220px; padding:20px; min-height:100vh; }
.table thead th { background:#34495e; color:white; }
.status { padding:4px 8px; border-radius:12px; font-size:13px; font-weight:bold; }
.status-selesai { background:#27ae60; color:white; }
.status-batal { background:#e74c3c; color:white; }
.status-pending { background:#f39c12; color:white; }

/* Style laporan untuk cetak */
.header-laporan { text-align:center; margin-bottom:20px; display:none; }
.header-laporan h2 { margin:0; }
@media print {
    body { background:white; }
    .sidebar, .text-center, .btn, .btn-success, .btn-primary { display:none !important; }
    .main { margin:0; }
    .header-laporan { display:block; }
    table, th, td { border:1px solid black !important; }

    /* Sembunyikan kolom Status saat print */
    th:nth-child(6),
    td:nth-child(6) {
        display: none;
    }
}

</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_penyewa.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="sewa_penyewa.php"><i class="fa fa-motorcycle"></i> Daftar Motor</a>
    <a href="riwayat_sewa.php" class="active"><i class="fa fa-history"></i> Riwayat Sewa</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">

    <!-- Header muncul hanya saat dicetak -->
    <!-- Tombol Aksi -->
<div class="text-center mt-3">
    <a href="sewa_penyewa.php" class="btn btn-primary">
        <i class="fa fa-motorcycle"></i> Sewa Motor Lagi
    </a>
    <button onclick="window.print()" class="btn btn-success">
        <i class="fa fa-print"></i> Cetak
    </button>
    <!-- Tombol Export Excel -->
    <a href="export_riwayat_excel.php" class="btn btn-warning">
        <i class="fa fa-file-excel"></i> Export Excel
    </a>
    <!-- Tombol Export PDF -->
    <a href="export_riwayat_pdf.php" class="btn btn-danger">
        <i class="fa fa-file-pdf"></i> Export PDF
    </a>
</div>


    <table class="table table-bordered table-striped" id="tabelRiwayat">
        <thead>
            <tr>
                <th>Motor</th>
                <th>Plat Nomor</th>
                <th>Tanggal Mulai</th>
                <th>Tanggal Selesai</th>
                <th>Tipe Durasi</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['merk']) ?></td>
                        <td><?= htmlspecialchars($row['plat_nomor']) ?></td>
                        <td><?= htmlspecialchars($row['tanggal_mulai']) ?></td>
                        <td><?= htmlspecialchars($row['tanggal_selesai']) ?></td>
                        <td><?= ucfirst($row['tipe_durasi']) ?></td>
                        <td>
                            <?php if ($row['status'] == 'pending'): ?>
                                <span class="status status-pending">Menunggu Verifikasi</span>
                            <?php elseif ($row['status'] == 'disetujui'): ?>
                                <span class="status status-selesai">Disetujui</span>
                            <?php elseif ($row['status'] == 'ditolak'): ?>
                                <span class="status status-batal">Ditolak</span>
                            <?php else: ?>
                                <span class="status"><?= htmlspecialchars($row['status']) ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="text-center">Belum ada data sewa.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
