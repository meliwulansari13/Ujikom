<?php
session_start();
include "koneksi.php";

$error = "";

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']); // sebaiknya pakai password_hash()

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['role'] = $row['role'];

        if ($row['role'] == 'admin') {
            header("Location: dashboard_admin.php");
        } else if ($row['role'] == 'pemilik') {
            header("Location: dashboard_pemilik.php");
        } else {
            header("Location: dashboard_penyewa.php");
        }
    } else {
        $error = "⚠️ Login gagal, periksa email dan password!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
    body {
        font-family: "Segoe UI", Tahoma, sans-serif;
        background: #f5f6fa;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .login-box {
        background: #fff;
        padding: 25px 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        width: 320px;
    }
    .login-box h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #2c3e50;
    }
    .input-group {
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 8px 10px;
        background: #fafafa;
    }
    .input-group i {
        margin-right: 8px;
        color: #888;
    }
    .input-group input {
        border: none;
        outline: none;
        flex: 1;
        background: transparent;
        font-size: 14px;
    }
    button {
        width: 100%;
        padding: 10px;
        background: #3498db;
        border: none;
        border-radius: 6px;
        color: white;
        font-size: 15px;
        cursor: pointer;
    }
    button:hover {
        background: #2980b9;
    }
    .error {
        color: red;
        font-size: 13px;
        margin-bottom: 10px;
        text-align: center;
    }
    .register-link {
        margin-top: 12px;
        text-align: center;
        font-size: 14px;
    }
    .register-link a {
        color: #3498db;
        text-decoration: none;
        font-weight: bold;
    }
    .register-link a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>

<div class="login-box">
    <h2><i class="fa fa-motorcycle"></i> Rental Motor</h2>
    <?php if($error) echo "<div class='error'>$error</div>"; ?>
    <form method="post">
        <div class="input-group">
            <i class="fa fa-envelope"></i>
            <input type="email" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
            <i class="fa fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <button type="submit" name="login"><i class="fa fa-sign-in-alt"></i> Login</button>
    </form>
    <div class="register-link">
        Belum punya akun? <a href="registrasi.php"><i class="fa fa-user-plus"></i> Daftar di sini</a>
    </div>
</div>

</body>
</html>
