<?php
session_start();
include "koneksi.php";
require('fpdf.php');

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit;
}

$penyewa_id = $_SESSION['user_id'];

// Ambil data sewa
$sql = "SELECT s.id, m.merk, m.plat_nomor, s.tanggal_mulai, s.tanggal_selesai, s.tipe_durasi, s.status
        FROM sewa s
        JOIN motor m ON s.motor_id = m.id
        WHERE s.penyewa_id = ?
        ORDER BY s.id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $penyewa_id);
$stmt->execute();
$result = $stmt->get_result();

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'Riwayat Sewa Motor',0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(35,7,'Motor',1);
$pdf->Cell(30,7,'Plat Nomor',1);
$pdf->Cell(30,7,'Tanggal Mulai',1);
$pdf->Cell(30,7,'Tanggal Selesai',1);
$pdf->Cell(30,7,'Tipe Durasi',1);
$pdf->Cell(35,7,'Status',1);
$pdf->Ln();

$pdf->SetFont('Arial','',10);
while($row = $result->fetch_assoc()){
    $status = ($row['status']=='pending') ? 'Menunggu Verifikasi' :
              (($row['status']=='disetujui') ? 'Disetujui' : 
              (($row['status']=='ditolak') ? 'Ditolak' : $row['status']));
    $pdf->Cell(35,7,$row['merk'],1);
    $pdf->Cell(30,7,$row['plat_nomor'],1);
    $pdf->Cell(30,7,$row['tanggal_mulai'],1);
    $pdf->Cell(30,7,$row['tanggal_selesai'],1);
    $pdf->Cell(30,7,$row['tipe_durasi'],1);
    $pdf->Cell(35,7,$status,1);
    $pdf->Ln();
}

$pdf->Output('D','Riwayat_Sewa.pdf');
?>
