<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil nama admin
$id_admin = $_SESSION['user_id'];
$q_admin = $conn->prepare("SELECT nama FROM users WHERE id=?");
$q_admin->bind_param("i", $id_admin);
$q_admin->execute();
$nama_admin = $q_admin->get_result()->fetch_assoc()['nama'] ?? 'Admin';

// Ambil data motor tersedia + tarif terbaru
$query = "
SELECT m.id, m.merk, m.tipe_cc, m.plat_nomor, m.status, m.photo,
       COALESCE(t.harga, m.harga_sewa) AS tarif_terbaru
FROM motor m
LEFT JOIN (
    SELECT motor_id, MAX(harga) AS harga
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
WHERE m.status='tersedia'
ORDER BY m.id ASC
";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Motor Tersedia</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, sans-serif;
    background: #f1f3f6;
}

/* Sidebar */
.sidebar {
    width: 230px;
    background: #111827;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    color: white;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
}
.sidebar h2 {
    text-align: center;
    padding: 20px;
    margin: 0;
    font-size: 20px;
    font-weight: bold;
    background: #1f2937;
    border-bottom: 2px solid #77aad4;
}
.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #cfd8dc;
    text-decoration: none;
    font-size: 14px;
    border-left: 4px solid transparent;
    transition: 0.3s;
}
.sidebar a:hover,
.sidebar a.active {
    background: #2563eb;
    color: #fff;
    border-left: 4px solid #fff;
}

/* Topbar */
.topbar {
    margin-left: 230px;
    background: linear-gradient(90deg, #2980b9, #8e44ad);
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    position: sticky;
    top: 0;
    z-index: 10;
}
.topbar h1 { margin: 0; font-size: 22px; font-weight: bold; }

/* Main Content */
.main { margin-left: 230px; padding: 20px; min-height: 100vh; }

/* Grid Cards */
.container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    justify-items: center;
}
.card {
    background: #fff;
    border-radius: 12px;
    padding: 10px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: column;
    max-width: 250px;
    width: 100%;
    transition: transform 0.2s, box-shadow 0.2s;
}
.card:hover {
    transform: translateY(-4px);
    box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}
.card img { width: 100%; height: 120px; object-fit: cover; border-radius: 10px; margin-bottom: 10px; }
.card h3 { margin: 0 0 10px; font-size: 18px; color: #34495e; text-align: center; }
.card p { margin: 4px 0; font-size: 14px; color: #7f8c8d; text-align: center; }

/* Status badge */
.status { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #fff; }
.tersedia { background: #27ae60; }

/* Button */
.button {
    margin-top: 10px;
    padding: 6px 12px;
    background: #3498db;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    text-align: center;
    font-size: 14px;
    display: inline-block;
}
.button:hover { background: #2980b9; }
</style>
</head>
<body>

<div class="sidebar">
<h2>RENTAL MOTOR</h2>
<a href="users.php"><i class="fa fa-users"></i> Data User</a>
<a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
<a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
<a href="konfirmasi_pengembalian.php"><i class="fa fa-undo"></i> Motor Pengembalian</a>
<a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
<a href="motor_tersedia.php" class="active"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
<a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
<a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
<a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
<a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
<a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
<a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
<a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
<a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
<a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
<a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
<a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
</div>

<div class="topbar">
<h1>Motor Tersedia</h1>
<div>
Admin: <?= htmlspecialchars($nama_admin); ?>
<a href="logout.php" style="color:white; text-decoration:none; padding:6px 10px; background:rgba(255,255,255,0.2); border-radius:6px; margin-left:10px;">
<i class="fa fa-sign-out-alt"></i> Logout</a>
</div>
</div>

<div class="main">
<div class="container">
<?php
if ($result->num_rows > 0) {
    while ($motor = $result->fetch_assoc()) {
        $photoPath = (!empty($motor['photo']) && file_exists("uploads_motor/".$motor['photo'])) 
                     ? "uploads_motor/".$motor['photo'] 
                     : "https://via.placeholder.com/400x200?text=No+Image";
        ?>
        <div class="card">
            <img src="<?= htmlspecialchars($photoPath) ?>" alt="Motor">
            <h3><?= htmlspecialchars($motor['merk']) ?> (<?= htmlspecialchars($motor['tipe_cc']) ?>)</h3>
            <p><i class="fa fa-id-card"></i> Plat: <?= htmlspecialchars($motor['plat_nomor']) ?></p>
            <p>Status: <span class="status tersedia"><?= htmlspecialchars($motor['status']) ?></span></p>
            <p><i class="fa fa-money-bill-wave"></i> Tarif: Rp <?= number_format($motor['tarif_terbaru'],0,',','.') ?></p>
            <a href="detail_motor.php?id=<?= $motor['id'] ?>" class="button"><i class="fa fa-info-circle"></i> Detail</a>
        </div>
        <?php
    }
} else {
    echo "<p style='grid-column:1/-1; text-align:center;'>Tidak ada motor tersedia</p>";
}
?>
</div>
</div>
</body>
</html>
