<?php
session_start();
include "koneksi.php";

// cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$id_pemilik = $_SESSION['user_id'];

// Ambil filter periode dari URL
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'bulan';

// Query total pendapatan berdasarkan periode khusus motor pemilik
switch($periode){
    case 'hari':
        $sql = "SELECT DATE(s.tanggal_selesai) AS periode, SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY DATE(s.tanggal_selesai)
                ORDER BY DATE(s.tanggal_selesai) DESC";
        break;
    case 'minggu':
        $sql = "SELECT YEAR(s.tanggal_selesai) AS tahun, WEEK(s.tanggal_selesai,1) AS minggu, 
                       SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY YEAR(s.tanggal_selesai), WEEK(s.tanggal_selesai,1)
                ORDER BY YEAR(s.tanggal_selesai) DESC, WEEK(s.tanggal_selesai,1) DESC";
        break;
    case 'tahun':
        $sql = "SELECT YEAR(s.tanggal_selesai) AS periode, SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY YEAR(s.tanggal_selesai)
                ORDER BY YEAR(s.tanggal_selesai) DESC";
        break;
    default: // bulan
        $sql = "SELECT DATE_FORMAT(s.tanggal_selesai, '%Y-%m') AS periode, SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY DATE_FORMAT(s.tanggal_selesai, '%Y-%m')
                ORDER BY DATE_FORMAT(s.tanggal_selesai, '%Y-%m') DESC";
}

// Prepare statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_pemilik);
$stmt->execute();
$result = $stmt->get_result();

$pendapatan = [];
while ($row = $result->fetch_assoc()) {
    if($periode=='minggu') {
        $row['periode'] = 'Tahun '.$row['tahun'].' - Minggu '.$row['minggu'];
    }
    $pendapatan[] = $row;
}

// Total keseluruhan pemilik
$sql_total = "SELECT SUM(s.total_harga) AS total_keseluruhan
              FROM sewa s
              JOIN motor m ON s.motor_id = m.id
              WHERE m.pemilik_id = ? AND s.status='selesai'";
$stmt_total = $conn->prepare($sql_total);
$stmt_total->bind_param("i", $id_pemilik);
$stmt_total->execute();
$res_total = $stmt_total->get_result();
$total_keseluruhan = $res_total->fetch_assoc()['total_keseluruhan'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Total Pendapatan - Pemilik</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* Reset & Body */
body {
    margin:0; font-family:'Segoe UI', sans-serif; background:#f4f6f9; display:flex; min-height:100vh;
}

/* Sidebar */
.sidebar {
    width:220px; background:#111827; color:white; display:flex; flex-direction:column; min-height:100vh;
}
.sidebar h2 { text-align:center; padding:20px 0; font-size:20px; border-bottom:1px solid rgba(255,255,255,0.2); }
.sidebar a { color:white; text-decoration:none; padding:12px 20px; display:block; transition:0.3s; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }

/* Main Content */
.main { flex:1; padding:20px; min-height:100vh; }
h1 { text-align:center; color:#34495e; margin-bottom:20px; }

/* Filter Periode */
.filter { text-align:center; margin-bottom:20px; }
.filter a {
    text-decoration:none; padding:8px 14px; margin:0 5px; background:#2980b9; color:white; border-radius:6px; font-weight:bold;
    transition:0.2s;
}
.filter a:hover { background:#1f6391; }
.filter a.active { background:#27ae60; }

/* Table */
table {
    width:100%; max-width:800px; margin:0 auto; border-collapse:collapse; background:#fff; border-radius:12px; overflow:hidden;
    box-shadow:0 3px 8px rgba(0,0,0,0.1);
}
th, td { padding:12px; text-align:center; border-bottom:1px solid #eee; }
th { background:#34495e; color:white; }
tr:nth-child(even) { background:#fafafa; }
tr:hover { background:#f1f1f1; }

/* Total Keseluruhan */
.total {
    font-size:22px; font-weight:bold; color:#27ae60; text-align:center; margin-top:20px;
}

/* Tombol Cetak & Export */
.btn-print {
    display:inline-block; padding:8px 14px; background:#27ae60; color:white; border-radius:6px; border:none;
    font-weight:bold; cursor:pointer; transition:0.3s; margin:0 5px;
}
.btn-print:hover { background:#1f8b4d; }

/* Print Mode */
@media print {
    .sidebar, .btn-print, .filter, h1 { display:none; }
    .main { margin:0; padding:0; }
    table { width:100%; border-collapse:collapse; }
    th, td { border:1px solid #000; padding:6px; text-align:center; }
    th { background:#eee; color:#000; }
    tr:nth-child(even) { background:#fff; }
    .total { margin-top:20px; font-size:20px; }
}

/* Responsif */
@media(max-width:768px) { .sidebar { width:180px; } .main { padding:15px; } }
@media(max-width:576px) { .sidebar { position:absolute; left:-220px; } .sidebar.active { left:0; } .main { margin-left:0; padding:10px; } }
</style>
</head>
<body>

<div class="sidebar">
    <h2>Pemilik</h2>
    <a href="dashboard_pemilik.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="motor_pemilik.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_tersedia_pemilik.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="generate_daftar_motor_disewa_pemilik.php"><i class="fa fa-list"></i> Motor Disewa</a>
    <a href="history_bagi_hasil_pemilik.php"><i class="fa fa-history"></i> Bagi Hasil</a>
    <a href="generate_total_pendapatan_pemilik.php" class="active"><i class="fa fa-wallet"></i> Total Pendapatan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
<h1>Total Pendapatan Saya</h1>

<!-- Tombol Cetak + Export -->
<div style="text-align:center; margin-bottom:15px;">
    <button class="btn-print" onclick="window.print();">
        <i class="fa fa-print"></i> Cetak
    </button>
    <a href="export_total_pendapatan_pemilik_pdf.php?periode=<?= $periode ?>" class="btn-print">
        <i class="fa fa-file-pdf"></i> Export PDF
    </a>
    <a href="export_total_pendapatan_pemilik_excel.php?periode=<?= $periode ?>" class="btn-print">
        <i class="fa fa-file-excel"></i> Export Excel
    </a>
</div>

<!-- Filter Periode -->
<div class="filter">
    <a href="?periode=hari" class="<?= $periode=='hari'?'active':'' ?>">Harian</a>
    <a href="?periode=minggu" class="<?= $periode=='minggu'?'active':'' ?>">Mingguan</a>
    <a href="?periode=bulan" class="<?= $periode=='bulan'?'active':'' ?>">Bulanan</a>
    <a href="?periode=tahun" class="<?= $periode=='tahun'?'active':'' ?>">Tahunan</a>
</div>

<!-- Tabel Pendapatan -->
<table>
    <tr>
        <th>No</th>
        <th>Periode</th>
        <th>Total Pendapatan (Rp)</th>
    </tr>
    <?php if(!empty($pendapatan)): ?>
        <?php foreach($pendapatan as $i => $p): ?>
        <tr>
            <td><?= $i+1 ?></td>
            <td><?= $p['periode'] ?></td>
            <td>Rp <?= number_format($p['total'],0,',','.') ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="3">Belum ada data pendapatan.</td>
        </tr>
    <?php endif; ?>
</table>

<!-- Total Keseluruhan -->
<div class="total">
    Total Keseluruhan: Rp <?= number_format($total_keseluruhan,0,',','.'); ?>
</div>
</div>

</body>
</html>
