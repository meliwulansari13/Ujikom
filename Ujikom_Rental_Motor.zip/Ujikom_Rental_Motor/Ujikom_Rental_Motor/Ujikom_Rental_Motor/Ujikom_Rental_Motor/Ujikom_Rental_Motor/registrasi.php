
<?php
session_start();
include "koneksi.php";

$error = "";
$success = "";

if (isset($_POST['registrasi'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = md5($_POST['password']); // bisa diganti password_hash()
    $role = $_POST['role'];
    $no_tlpn = $_POST['no_tlpn'];

    // cek email sudah ada atau belum
    $cek = $conn->prepare("SELECT * FROM users WHERE email=?");
    $cek->bind_param("s", $email);
    $cek->execute();
    $res = $cek->get_result();

    if ($res->num_rows > 0) {
        $error = "⚠️ Email sudah terdaftar!";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (nama, email, password, role, no_tlpn) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama, $email, $password, $role, $no_tlpn);
        if ($stmt->execute()) {
            $success = "✅ Registrasi berhasil! Silakan login.";
        } else {
            $error = "❌ Gagal registrasi: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Registrasi Akun</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
    body {
        font-family: "Segoe UI", Tahoma, sans-serif;
        background: #f5f6fa;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .register-box {
        background: #fff;
        padding: 25px 30px;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        width: 350px;
    }
    .register-box h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #2c3e50;
    }
    .input-group {
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        border: 1px solid #ccc;
        border-radius: 6px;
        padding: 8px 10px;
        background: #fafafa;
    }
    .input-group i {
        margin-right: 8px;
        color: #888;
    }
    .input-group input, .input-group select {
        border: none;
        outline: none;
        flex: 1;
        background: transparent;
        font-size: 14px;
    }
    button {
        width: 100%;
        padding: 10px;
        background: #27ae60;
        border: none;
        border-radius: 6px;
        color: white;
        font-size: 15px;
        cursor: pointer;
    }
    button:hover {
        background: #1e8449;
    }
    .error { color: red; font-size: 13px; margin-bottom: 10px; text-align: center; }
    .success { color: green; font-size: 13px; margin-bottom: 10px; text-align: center; }
    .login-link {
        margin-top: 12px;
        text-align: center;
        font-size: 14px;
    }
    .login-link a {
        color: #3498db;
        text-decoration: none;
        font-weight: bold;
    }
    .login-link a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>

<div class="register-box">
    <h2><i class="fa fa-user-plus"></i> Registrasi Akun</h2>
    <?php if($error) echo "<div class='error'>$error</div>"; ?>
    <?php if($success) echo "<div class='success'>$success</div>"; ?>

    <form method="post">
        <div class="input-group">
            <i class="fa fa-user"></i>
            <input type="text" name="nama" placeholder="Nama Lengkap" required>
        </div>
        <div class="input-group">
            <i class="fa fa-envelope"></i>
            <input type="email" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
            <i class="fa fa-phone"></i>
            <input type="text" name="no_tlpn" placeholder="No. Telepon" required>
        </div>
        <div class="input-group">
            <i class="fa fa-lock"></i>
            <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="input-group">
            <i class="fa fa-user-tag"></i>
            <select name="role" required>
                <option value="">Pilih Role</option>
                <option value="pemilik">Pemilik</option>
                <option value="penyewa">Penyewa</option>
                <option value="admin">admin</option>
            </select>
        </div>
        <button type="submit" name="registrasi"><i class="fa fa-save"></i> Daftar</button>
    </form>

    <div class="login-link">
        Sudah punya akun? <a href="login.php"><i class="fa fa-sign-in-alt"></i> Login</a>
    </div>
</div>
</body>
</html>