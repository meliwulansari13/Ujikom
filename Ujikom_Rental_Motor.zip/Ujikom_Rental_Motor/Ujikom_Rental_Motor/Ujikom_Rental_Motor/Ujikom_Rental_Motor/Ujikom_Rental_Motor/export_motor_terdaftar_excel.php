<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Query daftar motor + pemilik + harga terbaru
$sql = "
SELECT m.id, m.merk, m.tipe_cc, u.nama AS pemilik,
       COALESCE(t.harga, m.harga_sewa) AS harga_terbaru,
       m.status
FROM motor m
LEFT JOIN users u ON m.pemilik_id = u.id
LEFT JOIN (
    SELECT motor_id, MAX(harga) AS harga
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
ORDER BY m.id ASC
";

$result = $conn->query($sql);

// Header file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Daftar_Motor.xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Pemilik</th>
        <th>Merk</th>
        <th>Tipe/CC</th>
        <th>Harga Sewa (Rp)</th>
        <th>Status</th>
      </tr>";

if($result && $result->num_rows > 0) {
    $no = 1;
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$no++."</td>";
        echo "<td>".htmlspecialchars($row['pemilik'])."</td>";
        echo "<td>".htmlspecialchars($row['merk'])."</td>";
        echo "<td>".htmlspecialchars($row['tipe_cc'])."</td>";
        echo "<td>".number_format($row['harga_terbaru'],0,',','.')."</td>";
        echo "<td>".htmlspecialchars(ucfirst($row['status']))."</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>Belum ada motor terdaftar</td></tr>";
}

echo "</table>";
exit;
?>
