<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit;
}
include "koneksi.php";

$id_penyewa = intval($_SESSION['user_id']);

// Ambil semua motor beserta tarif & dokumen
$motor_res = $conn->query("
    SELECT m.id, m.merk, m.tipe_cc, m.plat_nomor, m.photo, m.dokumen_kepemilikan, m.status,
        MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS tarif_harian,
        MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS tarif_mingguan,
        MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS tarif_bulanan
    FROM motor m
    LEFT JOIN tarif t ON m.id=t.motor_id AND t.status='aktif'
    GROUP BY m.id
    ORDER BY m.merk
");

// Fungsi untuk menampilkan foto motor dengan fallback
function motorPhoto($foto){
    $default = 'uploads_motor/default.jpg';
    if(!empty($foto) && file_exists('uploads_motor/'.basename($foto))){
        return 'uploads_motor/'.basename($foto);
    }
    return $default;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Daftar Motor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { background:#f4f6f9; font-family:'Segoe UI', sans-serif; margin:0; }
.sidebar { width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; }
.sidebar h2 { text-align:center; margin-bottom:20px; font-size:18px; }
.sidebar a { display:block; color:white; padding:10px 20px; text-decoration:none; font-size:14px; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }
.main { margin-left:220px; padding:20px; min-height:100vh; }
.motor-grid { display:flex; flex-wrap:wrap; gap:1rem; justify-content:flex-start; }
.motor-card { flex:0 0 18%; max-width:18%; display:flex; flex-direction:column; background:#fff; border-radius:12px; transition:0.3s; overflow:hidden; }
.motor-card:hover { transform:translateY(-5px); box-shadow:0 8px 20px rgba(0,0,0,0.2); }
.motor-card img { height:130px; object-fit:cover; border-radius:12px 12px 0 0; width:100%; }
.card-body { display:flex; flex-direction:column; padding:10px; }
.card-title { font-weight:bold; font-size:14px; margin-bottom:4px; }
.badge-tarif { font-size:12px; margin-right:3px; margin-bottom:2px; display:inline-block; }
.btn-detail { background:#7f8c8d; color:#fff; font-size:13px; padding:5px 0; margin-bottom:5px; }
.btn-detail:hover { background:#636e72; }
.btn-sewa { background:#2980b9; color:#fff; border:none; transition:0.3s; font-size:13px; padding:6px 0; }
.btn-sewa:hover { background:#1f6391; }
.alert-status { text-align:center; font-weight:bold; font-size:13px; padding:6px 0; }
/* Responsif */
@media(max-width:1200px){ .motor-card { flex:0 0 22%; max-width:22%; } }
@media(max-width:992px){ .motor-card { flex:0 0 31%; max-width:31%; } }
@media(max-width:768px){ .motor-card { flex:0 0 45%; max-width:45%; } }
@media(max-width:576px){ .motor-card { flex:0 0 90%; max-width:90%; } }
</style>
</head>
<body>
<div class="sidebar">
    <h2>PENYEWA</h2>
    <a href="dashboard_penyewa.php"><i class="fa fa-history"></i> Dashboard Penyewa</a>
    <a href="sewa_penyewa.php" class="active"><i class="fa fa-motorcycle"></i> Daftar Motor</a>
    <a href="riwayat_sewa.php"><i class="fa fa-history"></i> Riwayat Sewa</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <h2 class="mb-4 text-center">Daftar Motor</h2>
    <div class="motor-grid">
        <?php while($m = $motor_res->fetch_assoc()): 
            $status_motor = $m['status'] ?? 'tersedia';
        ?>
        <div class="motor-card">
            <img src="<?= motorPhoto($m['photo']) ?>" alt="Motor <?= htmlspecialchars($m['merk'].' '.$m['tipe_cc']) ?>">
            <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($m['merk'].' '.$m['tipe_cc']) ?></h5>
                <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($m['plat_nomor']) ?></p>
                <div class="mb-2">
                    <?php if($m['tarif_harian'] !== null): ?><span class="badge bg-primary badge-tarif">Harian: Rp <?= number_format($m['tarif_harian']) ?></span><?php endif; ?>
                    <?php if($m['tarif_mingguan'] !== null): ?><span class="badge bg-success badge-tarif">Mingguan: Rp <?= number_format($m['tarif_mingguan']) ?></span><?php endif; ?>
                    <?php if($m['tarif_bulanan'] !== null): ?><span class="badge bg-warning text-dark badge-tarif">Bulanan: Rp <?= number_format($m['tarif_bulanan']) ?></span><?php endif; ?>
                </div>

                <button type="button" class="btn btn-detail" data-bs-toggle="modal" data-bs-target="#detailModal<?= $m['id'] ?>">
                    <i class="fa fa-eye"></i> Detail
                </button>
            </div>
        </div>

        <!-- Modal Detail -->
        <div class="modal fade" id="detailModal<?= $m['id'] ?>" tabindex="-1" aria-labelledby="detailModalLabel<?= $m['id'] ?>" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel<?= $m['id'] ?>">Detail Motor 
                <?= $status_motor === 'tersedia' ? htmlspecialchars($m['merk'].' '.$m['tipe_cc']) : "Motor Sedang Tidak Tersedia" ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <?php if($status_motor === 'tersedia'): ?>
                    <p><strong>Merk:</strong> <?= htmlspecialchars($m['merk']) ?></p>
                    <p><strong>Tipe CC:</strong> <?= htmlspecialchars($m['tipe_cc']) ?></p>
                    <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($m['plat_nomor']) ?></p>
                    <p><strong>Tarif:</strong><br>
                        <?php if($m['tarif_harian'] !== null) echo "Harian: Rp ".number_format($m['tarif_harian'])."<br>"; ?>
                        <?php if($m['tarif_mingguan'] !== null) echo "Mingguan: Rp ".number_format($m['tarif_mingguan'])."<br>"; ?>
                        <?php if($m['tarif_bulanan'] !== null) echo "Bulanan: Rp ".number_format($m['tarif_bulanan'])."<br>"; ?>
                    </p>
                    <p><strong>Dokumen:</strong><br>
                        <?php 
                        $dokumen = json_decode($m['dokumen_kepemilikan'], true);
                        if($dokumen && is_array($dokumen)):
                            foreach($dokumen as $file):
                                if(file_exists('uploads_dokumen/'.$file)):
                        ?>
                        <a href="uploads_dokumen/<?= htmlspecialchars($file) ?>" target="_blank"><i class="fa fa-file-pdf"></i> <?= htmlspecialchars($file) ?></a><br>
                        <?php 
                                endif;
                            endforeach;
                        else:
                            echo "Tidak tersedia";
                        endif;
                        ?>
                    </p>
                    <a href="pembayaran_penyewa.php?motor_id=<?= $m['id'] ?>" class="btn btn-sewa w-100"><i class="fa fa-motorcycle"></i> Sewa Motor</a>
                <?php elseif($status_motor === 'disewa'): ?>
                    <div class="alert alert-danger text-center">Motor ini sedang disewa, data bersifat privat.</div>
                <?php elseif($status_motor === 'perawatan'): ?>
                    <div class="alert alert-warning text-center">Motor ini sedang perbaikan, data bersifat privat.</div>
                <?php endif; ?>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
              </div>
            </div>
          </div>
        </div>

        <?php endwhile; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
