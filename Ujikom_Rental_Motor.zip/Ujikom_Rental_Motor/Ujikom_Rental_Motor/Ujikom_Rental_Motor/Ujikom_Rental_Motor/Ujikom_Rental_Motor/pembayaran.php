<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

// --- Search ---
$keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$params = [];
$search_sql = "";
if ($keyword != "") {
    $search_sql = " WHERE u.nama LIKE ? OR m.merk LIKE ? OR m.tipe_cc LIKE ? OR p.metode LIKE ? ";
    $like = "%$keyword%";
    $params = [$like, $like, $like, $like];
}

// --- Data Query tanpa pagination ---
$sql = "SELECT p.*, s.tanggal_mulai, s.tanggal_selesai, u.nama AS penyewa, m.merk, m.tipe_cc
        FROM pembayaran p
        JOIN sewa s ON p.sewa_id = s.id
        JOIN users u ON s.penyewa_id = u.id
        JOIN motor m ON s.motor_id = m.id"
        . $search_sql . 
        " ORDER BY p.tanggal_bayar ASC";

$stmt = $conn->prepare($sql);
if(!empty($params)) {
    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Pembayaran</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Segoe UI', sans-serif; background:#f4f6f9; margin:0; }
.sidebar { width: 230px; background: #111827; color: #fff; height: 100vh; position: fixed; top: 0; left: 0; display: flex; flex-direction: column; overflow-y: auto; }
.sidebar h2 { text-align: center; padding: 20px; margin: 0; font-size: 20px; background: #1f2937; border-bottom: 2px solid #2563eb; }
.sidebar a { display: block; padding: 14px 20px; color: #cfd8dc; text-decoration: none; font-size: 14px; border-left: 4px solid transparent; transition: 0.3s; }
.sidebar a:hover, .sidebar a.active { background: #1f2937; color: #fff; border-left: 4px solid #2563eb; }
.main { margin-left: 230px; padding: 20px; }
h1 { text-align:center; margin-bottom:20px; color:#34495e; }
.btn-back, .btn-add, .btn-reset { display:inline-block; padding:8px 14px; border-radius:6px; color:white; text-decoration:none; margin-bottom:15px; }
.btn-back { background:#7f8c8d; } .btn-back:hover { background:#616d70; }
.btn-add { background:#27ae60; } .btn-add:hover { background:#1f8b4d; }
.btn-reset { background:#e67e22; } .btn-reset:hover { background:#d35400; }
.search-box { display:flex; gap:10px; margin-bottom:15px; }
.search-box input { padding:7px 12px; border-radius:6px; border:1px solid #ccc; width:220px; }
.search-box button { padding:7px 12px; border:none; background:#2980b9; color:white; border-radius:6px; cursor:pointer; }
.search-box button:hover { background:#1f6391; }
table { width:100%; border-collapse:collapse; background:white; border-radius:12px; overflow:hidden; box-shadow:0 3px 8px rgba(0,0,0,0.1); }
th, td { padding:12px; text-align:center; border-bottom:1px solid #eee; font-size:14px; }
th { background:#34495e; color:white; }
tr:nth-child(even) { background:#fafafa; }
tr:hover { background:#f1f1f1; }
.aksi a { padding:6px 12px; border-radius:5px; font-size:13px; color:white; text-decoration:none; margin:0 3px; display:inline-block; }
.edit { background:#17a2b8; } .hapus { background:#dc3545; }
</style>
</head>
<body>

<div class="sidebar">
<h2>RENTAL MOTOR</h2>
<a href="users.php"><i class="fa fa-users"></i> Data User</a>
<a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
<a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
<a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
<a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
<a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
<a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
<a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
<a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
<a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
<a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
<a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
<a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
<a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
<h1>Data Pembayaran</h1>

<a href="pembayaran_add.php" class="btn-add"><i class="fa fa-plus"></i> Tambah Pembayaran</a>

<form method="get" class="search-box">
    <input type="text" name="search" placeholder="Cari penyewa / motor / metode..." value="<?= htmlspecialchars($keyword) ?>">
    <button type="submit"><i class="fa fa-search"></i> Cari</button>
    <?php if($keyword != ""): ?>
        <a href="pembayaran.php" class="btn-reset"><i class="fa fa-undo"></i> Reset</a>
    <?php endif; ?>
</form>

<table>
<tr>
    <th>No</th>
    <th>Penyewa</th>
    <th>Motor</th>
    <th>Tanggal Bayar</th>
    <th>Jumlah</th>
    <th>Metode</th>
    <th>Aksi</th>
</tr>
<?php if($result->num_rows>0):
    $no = 1;
    while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= htmlspecialchars($row['penyewa']) ?></td>
    <td><?= htmlspecialchars($row['merk'].' '.$row['tipe_cc']) ?></td>
    <td><?= date('d-m-Y H:i', strtotime($row['tanggal_bayar'])) ?></td>
    <td>Rp <?= number_format($row['jumlah'],0,',','.') ?></td>
    <td><?= ucfirst($row['metode']) ?></td>
    <td class="aksi">
        <a href="pembayaran_edit.php?id=<?= $row['id'] ?>" class="edit"><i class="fa fa-edit"></i> Edit</a>
        <a href="pembayaran_delete.php?id=<?= $row['id'] ?>" class="hapus" onclick="return confirm('Hapus pembayaran ini?')"><i class="fa fa-trash"></i> Hapus</a>
    </td>
</tr>
<?php endwhile; else: ?>
<tr><td colspan="7">Tidak ada data ditemukan</td></tr>
<?php endif; ?>
</table>

</div>
</body>
</html>
