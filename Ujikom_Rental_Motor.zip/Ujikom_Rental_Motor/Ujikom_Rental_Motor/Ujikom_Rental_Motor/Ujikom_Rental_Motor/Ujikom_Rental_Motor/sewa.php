<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

// Search
$keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_sql = "";
$params = [];
if ($keyword != "") {
    $search_sql = " WHERE m.merk LIKE ? OR m.plat_nomor LIKE ? OR u.nama LIKE ?";
    $keyword_param = "%$keyword%";
    $params = [$keyword_param, $keyword_param, $keyword_param];
}

// Query data (tanpa pagination)
$sql = "SELECT s.*, m.merk, m.tipe_cc, m.plat_nomor, u.nama AS penyewa,
        GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) AS lama_sewa,
        CASE s.tipe_durasi
            WHEN 'harian' THEN COALESCE(t_harga.tarif_harian,0)
            WHEN 'mingguan' THEN COALESCE(t_harga.tarif_mingguan,0)
            WHEN 'bulanan' THEN COALESCE(t_harga.tarif_bulanan,0)
        END AS harga_satuan,
        GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) *
        CASE s.tipe_durasi
            WHEN 'harian' THEN COALESCE(t_harga.tarif_harian,0)
            WHEN 'mingguan' THEN COALESCE(t_harga.tarif_mingguan,0)
            WHEN 'bulanan' THEN COALESCE(t_harga.tarif_bulanan,0)
        END AS total_harga
    FROM sewa s
    JOIN motor m ON s.motor_id = m.id
    JOIN users u ON s.penyewa_id = u.id
    LEFT JOIN (
        SELECT motor_id,
               MAX(CASE WHEN jenis='harian' THEN harga END) AS tarif_harian,
               MAX(CASE WHEN jenis='mingguan' THEN harga END) AS tarif_mingguan,
               MAX(CASE WHEN jenis='bulanan' THEN harga END) AS tarif_bulanan
        FROM tarif
        WHERE status='aktif'
        GROUP BY motor_id
    ) t_harga ON t_harga.motor_id = m.id
    $search_sql
    ORDER BY s.tanggal_mulai ASC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Penyewaan</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{margin:0;font-family:'Segoe UI',sans-serif;background:#f4f6f9;}
.sidebar {
    width: 230px;
    background: #111827;
    color: #fff;
    height: 100vh;
    position: fixed;
    top: 0; left: 0;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
}
.sidebar h2 {
    text-align: center;
    padding: 20px;
    margin: 0;
    font-size: 20px;
    background: #1f2937;
    border-bottom: 2px solid #2563eb;
    color: #fff;
}
.sidebar a {
    display: block;
    padding: 14px 20px;
    color: #cfd8dc;
    text-decoration: none;
    font-size: 14px;
    border-left: 4px solid transparent;
    transition: 0.3s;
}
.sidebar a:hover,
.sidebar a.active {
    background: #1f2937;
    color: #fff;
    border-left: 4px solid #2563eb;
}

.main{margin-left:230px;padding:20px;}
h1{margin-bottom:20px;color:#34495e;}
.btn-back,.btn-add,.btn-reset{display:inline-block;padding:8px 14px;border-radius:6px;color:white;text-decoration:none;margin-bottom:15px;}
.btn-back{background:#7f8c8d;} .btn-back:hover{background:#616d70;}
.btn-add{background:#27ae60;} .btn-add:hover{background:#1f8b4d;}
.btn-reset{background:#f43f5e;} .btn-reset:hover{background:#e11d48;}
.search-box{display:flex;gap:10px;margin-bottom:15px;}
.search-box input{padding:7px 12px;border-radius:6px;border:1px solid #ccc;width:220px;}
.search-box button{padding:7px 12px;border:none;background:#2980b9;color:white;border-radius:6px;cursor:pointer;}
.search-box button:hover{background:#1f6391;}
table{width:100%;border-collapse:collapse;background:white;border-radius:12px;overflow:hidden;box-shadow:0 3px 8px rgba(0,0,0,0.1);}
th,td{padding:12px;text-align:center;border-bottom:1px solid #eee;font-size:14px;}
th{background:#34495e;color:white;}
tr:nth-child(even){background:#fafafa;}
tr:hover{background:#f1f1f1;}
.aksi a{padding:6px 12px;border-radius:5px;font-size:13px;color:white;text-decoration:none;margin:0 3px;display:inline-block;}
.edit{background:#17a2b8;}
.hapus{background:#dc3545;}
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php" class="active"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
<h1>Kelola Data Penyewaan</h1>

<form method="get" class="search-box">
    <input type="text" name="search" placeholder="Cari motor / penyewa..." value="<?= htmlspecialchars($keyword) ?>">
    <button type="submit"><i class="fa fa-search"></i> Cari</button>
    <?php if($keyword != ""): ?>
        <a href="sewa.php" class="btn-reset"><i class="fa fa-undo"></i> Reset</a>
    <?php endif; ?>
</form>

<table>
<tr>
    <th>No</th>
    <th>Motor</th>
    <th>Penyewa</th>
    <th>Tanggal Mulai</th>
    <th>Tanggal Selesai</th>
    <th>Lama Sewa</th>
    <th>Harga Satuan</th>
    <th>Total Harga</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>
<?php if($result->num_rows > 0): 
    $no = 1;
    while($row = $result->fetch_assoc()):
?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= htmlspecialchars($row['merk'].' '.$row['tipe_cc'].' / '.$row['plat_nomor']) ?></td>
    <td><?= htmlspecialchars($row['penyewa']) ?></td>
    <td><?= $row['tanggal_mulai'] ?></td>
    <td><?= $row['tanggal_selesai'] ?></td>
    <td><?= $row['lama_sewa'] ?> hari</td>
    <td>Rp <?= number_format($row['harga_satuan'],0,',','.') ?></td>
    <td>Rp <?= number_format($row['total_harga'],0,',','.') ?></td>
    <td><?= ucfirst($row['status']) ?></td>
    <td class="aksi">
        <a href="sewa_detail.php?id=<?= $row['id'] ?>" class="lihat" style="background:#2980b9;"><i class="fa fa-eye"></i> Lihat</a>
        <a href="sewa_edit.php?id=<?= $row['id'] ?>" class="edit"><i class="fa fa-edit"></i> Edit</a>
        <a href="sewa_delete.php?id=<?= $row['id'] ?>" class="hapus" onclick="return confirm('Hapus penyewaan ini?')"><i class="fa fa-trash"></i> Hapus</a>
    </td>
</tr>
<?php endwhile; else: ?>
<tr>
    <td colspan="10">Tidak ada data ditemukan</td>
</tr>
<?php endif; ?>
</table>
</div>

</body>
</html>
