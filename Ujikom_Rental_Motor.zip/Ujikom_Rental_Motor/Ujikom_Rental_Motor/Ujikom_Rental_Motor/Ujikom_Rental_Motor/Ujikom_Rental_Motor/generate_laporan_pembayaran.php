<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$status_filter = isset($_GET['status']) ? $_GET['status'] : 'Pending';

// Query pembayaran
$sql = "
SELECT 
    pb.id,
    u.nama AS penyewa,
    m.merk,
    m.plat_nomor,
    COALESCE(
        (DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1) * 
        COALESCE(t.harga, m.harga_sewa, 0), 
        0
    ) AS jumlah,
    IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) AS status,
    pb.tanggal_bayar
FROM pembayaran pb
JOIN sewa s ON pb.sewa_id = s.id
JOIN users u ON s.penyewa_id = u.id
JOIN motor m ON s.motor_id = m.id
LEFT JOIN (
    SELECT motor_id, MAX(harga) AS harga
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
WHERE IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) = ?
ORDER BY pb.tanggal_bayar ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $status_filter);
$stmt->execute();
$result = $stmt->get_result();

// Total pembayaran
$sql_total = "
SELECT SUM((DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1) *
           COALESCE(t.harga, m.harga_sewa, 0)) AS total_pembayaran
FROM pembayaran pb
JOIN sewa s ON pb.sewa_id = s.id
JOIN motor m ON s.motor_id = m.id
LEFT JOIN (
    SELECT motor_id, MAX(harga) AS harga
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
WHERE IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) = ?
";

$stmt_total = $conn->prepare($sql_total);
$stmt_total->bind_param("s", $status_filter);
$stmt_total->execute();
$total_result = $stmt_total->get_result();
$total_row = $total_result->fetch_assoc();
$total_pembayaran = $total_row['total_pembayaran'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan Konfirmasi Pembayaran</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f4f6f9; color:#333;}
.sidebar {width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; overflow-y:auto;}
.sidebar h2 {text-align:center; margin-bottom:20px; font-size:18px;}
.sidebar a {display:block; color:#cfd8dc; padding:12px 20px; text-decoration:none; font-size:14px; border-left:4px solid transparent; transition:0.3s;}
.sidebar a:hover, .sidebar a.active {background:#1f2937; color:#fff; border-left:4px solid #2563eb;}
.main {margin-left:220px; padding:20px;}
.card {background:#fff; border-radius:12px; padding:20px; box-shadow:0 3px 8px rgba(0,0,0,0.1);}
h2.title {text-align:center; margin-bottom:5px;}
h4.subtitle {text-align:center; margin-top:0;margin-bottom:15px;}
table {width:100%; border-collapse:collapse; margin-top:15px;}
th, td {padding:12px; text-align:center; border-bottom:1px solid #eee; font-size:14px;}
th {background:#34495e; color:white;}
tr:nth-child(even) {background:#f9f9f9;}
tr:hover {background:#f1f1f1;}
.status-pending {color:orange; font-weight:bold;}
.status-lunas {color:green; font-weight:bold;}
.total-box {text-align:right; margin-top:15px; font-weight:bold; font-size:16px;}
.btn {display:inline-block; margin:5px 5px 15px 0; padding:8px 16px; background:#2563eb; color:white; border:none; border-radius:6px; cursor:pointer; text-decoration:none; font-size:14px;}
.btn:hover {background:#1d4ed8;}
.print-header {display:none; text-align:center; margin-bottom:20px;}
.print-header h2 {margin:0; font-size:22px;}
.print-header h3 {margin:5px 0; font-size:16px;}
.print-header hr {border:1px solid #000; margin-top:8px;}
@media print {
    body {background:#fff;}
    .sidebar, .btn, form, .title, .subtitle {display:none !important;}
    .main {margin:0; padding:0;}
    table, .total-box, .card {box-shadow:none;}
    .print-header {display:block;}
    tr:nth-child(even){background:#fff;}
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a> 
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php" class="active"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <div class="card">
        <div class="print-header">
            <h2>Laporan Konfirmasi Pembayaran</h2>
            <h3>Tanggal Cetak: <?= date('d-m-Y'); ?></h3>
            <hr>
        </div>

        <h2 class="title">📄 Laporan Konfirmasi Pembayaran</h2>
        <h4 class="subtitle">Tanggal Cetak: <?= date('d-m-Y'); ?></h4>

        <!-- Filter -->
        <form method="GET" style="text-align:center; margin-bottom:15px;">
            <label for="status">Tampilkan:</label>
            <select name="status" id="status" onchange="this.form.submit()">
                <option value="Pending" <?= $status_filter=='Pending'?'selected':''; ?>>Pembayaran Pending</option>
                <option value="Lunas" <?= $status_filter=='Lunas'?'selected':''; ?>>Pembayaran Lunas</option>
            </select>
        </form>

        <!-- Tombol -->
        <a href="export_pembayaran_pdf.php?status=<?= $status_filter; ?>" class="btn"><i class="fa fa-file-excel"></i> Export Pdf</a>
        <a href="export_pembayaran_excel.php?status=<?= $status_filter; ?>" class="btn"><i class="fa fa-file-excel"></i> Export Excel</a>
        <button class="btn" onclick="window.print()"><i class="fa fa-print"></i> Cetak</button>

        <!-- Tabel -->
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Penyewa</th>
                    <th>Motor</th>
                    <th>Tanggal Bayar</th>
                    <th>Jumlah (Rp)</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if($result && $result->num_rows>0): $i=1; while($row=$result->fetch_assoc()): ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><?= htmlspecialchars($row['penyewa']); ?></td>
                    <td><?= htmlspecialchars($row['merk'].' ('.$row['plat_nomor'].')'); ?></td>
                    <td><?= htmlspecialchars($row['tanggal_bayar']); ?></td>
                    <td>Rp <?= number_format($row['jumlah'],0,',','.'); ?></td>
                    <td class="<?= strtolower($row['status'])=='lunas'?'status-lunas':'status-pending'; ?>">
                        <?= htmlspecialchars($row['status']); ?>
                    </td>
                </tr>
            <?php endwhile; else: ?>
                <tr><td colspan="6">Tidak ada pembayaran dengan status <?= htmlspecialchars($status_filter); ?>.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>

        <div class="total-box">
            Total Pembayaran <?= htmlspecialchars($status_filter); ?>: Rp <?= number_format($total_pembayaran,0,',','.'); ?>
        </div>
    </div>
</div>

</body>
</html>
