<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil status sewa dari URL (opsional)
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'Semua';

// Query data riwayat penyewaan
$sql = "
SELECT 
    s.id,
    u.nama AS penyewa,
    m.merk,
    m.tipe_cc,
    m.plat_nomor,
    s.tanggal_mulai,
    s.tanggal_selesai,
    s.status
FROM sewa s
JOIN users u ON s.penyewa_id = u.id
JOIN motor m ON s.motor_id = m.id
";

// Tambahkan filter status jika bukan semua
if($status_filter != 'Semua'){
    $sql .= " WHERE s.status = ?";
}

$sql .= " ORDER BY s.id DESC";

if($status_filter != 'Semua'){
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $status_filter);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

// Header file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Riwayat_Penyewaan_{$status_filter}.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Tabel Excel
echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Penyewa</th>
        <th>Motor</th>
        <th>Tanggal Mulai</th>
        <th>Tanggal Selesai</th>
        <th>Status</th>
      </tr>";

if($result && $result->num_rows > 0) {
    $i = 1;
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$i++."</td>";
        echo "<td>".htmlspecialchars($row['penyewa'])."</td>";
        echo "<td>".htmlspecialchars($row['merk']." ".$row['tipe_cc']." / ".$row['plat_nomor'])."</td>";
        echo "<td>".htmlspecialchars($row['tanggal_mulai'])."</td>";
        echo "<td>".htmlspecialchars($row['tanggal_selesai'])."</td>";
        echo "<td>".htmlspecialchars($row['status'])."</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>Tidak ada data riwayat penyewaan dengan status ".htmlspecialchars($status_filter)."</td></tr>";
}

echo "</table>";
exit;
?>
