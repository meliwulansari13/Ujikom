<?php
session_start();
include "koneksi.php";

// Pastikan role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$success = "";
$error   = "";

// Ambil data penyewa & motor
$penyewa = $conn->query("SELECT * FROM users WHERE role='penyewa'");
$motor   = $conn->query("SELECT * FROM motor");

// Proses simpan transaksi
if (isset($_POST['simpan'])) {
    $penyewa_id    = (int)$_POST['penyewa_id'];
    $motor_id      = (int)$_POST['motor_id'];
    $tipe_durasi   = $_POST['tipe_durasi'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $status        = $_POST['status'];
    $metode        = "Cash";

    // Hitung tanggal selesai sesuai tipe durasi
    switch($tipe_durasi){
        case 'harian':
            $tanggal_kembali = date('Y-m-d', strtotime($tanggal_mulai . ' +1 day'));
            break;
        case 'mingguan':
            $tanggal_kembali = date('Y-m-d', strtotime($tanggal_mulai . ' +7 days'));
            break;
        case 'bulanan':
            $tanggal_kembali = date('Y-m-d', strtotime($tanggal_mulai . ' +1 month'));
            break;
        default:
            $tanggal_kembali = $tanggal_mulai;
    }

    // Ambil harga motor dari tarif aktif atau fallback ke harga sewa default
    $res_harga = $conn->query("
        SELECT m.id, COALESCE(t.harga, m.harga_sewa) AS harga 
        FROM motor m
        LEFT JOIN tarif t ON t.motor_id=m.id AND t.status='aktif'
        WHERE m.id=$motor_id LIMIT 1
    ");
    $data_harga = $res_harga->fetch_assoc();
    $jumlah = (float)($data_harga['harga'] ?? 0);

    // Insert sewa
    $stmt_sewa = $conn->prepare("
        INSERT INTO sewa (penyewa_id, motor_id, tanggal_mulai, tanggal_selesai, total_harga, status)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt_sewa->bind_param("iissds", $penyewa_id, $motor_id, $tanggal_mulai, $tanggal_kembali, $jumlah, $status);

    if ($stmt_sewa->execute()) {
        $sewa_id = $conn->insert_id;

        // Insert pembayaran
        $tanggal_bayar = date("Y-m-d");
        $stmt_bayar = $conn->prepare("
            INSERT INTO pembayaran (sewa_id, jumlah, metode, tanggal_bayar)
            VALUES (?, ?, ?, ?)
        ");
        $stmt_bayar->bind_param("idss", $sewa_id, $jumlah, $metode, $tanggal_bayar);
        $stmt_bayar->execute();

        // Ambil pemilik motor
        $stmt_motor = $conn->prepare("SELECT pemilik_id FROM motor WHERE id=?");
        $stmt_motor->bind_param("i", $motor_id);
        $stmt_motor->execute();
        $result_motor = $stmt_motor->get_result();
        $row_motor = $result_motor->fetch_assoc();
        $pemilik_id = $row_motor['pemilik_id'] ?? 0;

        // Hitung bagi hasil
        $bagi_pemilik = $jumlah * 0.6;
        $bagi_admin   = $jumlah * 0.4;

        $stmt_history = $conn->prepare("
            INSERT INTO history_bagi_hasil
            (sewa_id, motor_id, pemilik_id, total_pendapatan, bagi_pemilik, bagi_admin, tanggal)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt_history->bind_param("iiiddd", $sewa_id, $motor_id, $pemilik_id, $jumlah, $bagi_pemilik, $bagi_admin);
        $stmt_history->execute();

        $success = "Transaksi berhasil disimpan!";
    } else {
        $error = "Gagal simpan transaksi: " . $stmt_sewa->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Entri Transaksi</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI',sans-serif; background:#f0f2f5; color:#333; }
.sidebar { width:230px; background:#1f2937; color:white; height:100vh; position:fixed; top:0; left:0; padding-top:20px; box-shadow:2px 0 8px rgba(0,0,0,0.2); overflow-y:auto; }
.sidebar h2 { text-align:center; font-size:18px; margin-bottom:25px; color:#fff; letter-spacing:1px; }
.sidebar a { display:flex; align-items:center; gap:10px; color:#d1d5db; padding:12px 20px; text-decoration:none; font-size:14px; transition:all 0.3s; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; color:#fff; }
.main { margin-left:230px; padding:40px; min-height:100vh; display:flex; justify-content:center; align-items:flex-start; }
.card { background:#fff; border-radius:12px; padding:30px; box-shadow:0 6px 16px rgba(0,0,0,0.1); width:100%; max-width:600px; }
h2 { text-align:center; margin-bottom:25px; color:#2563eb; }
.input-group { margin-bottom:18px; }
label { display:block; margin-bottom:6px; font-weight:600; color:#374151; }
input, select { width:100%; padding:10px; border:1px solid #cbd5e1; border-radius:8px; font-size:14px; transition:border 0.3s; }
input:focus, select:focus { border-color:#2563eb; outline:none; box-shadow:0 0 0 2px rgba(37,99,235,0.2); }
input[readonly] { background:#e5e7eb; }
button { width:100%; padding:12px; background:#2563eb; color:white; border:none; border-radius:8px; font-size:15px; cursor:pointer; font-weight:bold; transition:background 0.3s; }
button:hover { background:#1d4ed8; }
.back { display:block; text-align:center; margin-top:18px; text-decoration:none; color:#2563eb; font-weight:bold; }
.msg { text-align:center; margin-bottom:15px; font-size:14px; }
.success { color:green; } .error { color:red; }
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-undo"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php" class="active"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <div class="card">
        <h2><i class="fa fa-credit-card"></i> Form Transaksi</h2>
        <?php if ($success) echo "<div class='msg success'>$success</div>"; ?>
        <?php if ($error) echo "<div class='msg error'>$error</div>"; ?>

        <form method="post">
            <div class="input-group">
                <label>Penyewa</label>
                <select name="penyewa_id" required>
                    <option value="">-- Pilih Penyewa --</option>
                    <?php while($row = $penyewa->fetch_assoc()) { ?>
                        <option value="<?= $row['id'] ?>"><?= $row['nama'] ?> (<?= $row['email'] ?>)</option>
                    <?php } ?>
                </select>
            </div>

            <div class="input-group">
                <label>Motor</label>
                <select name="motor_id" id="motor_id" required onchange="updateTotal()">
                    <option value="">-- Pilih Motor --</option>
                    <?php 
                    $motor->data_seek(0);
                    while($row = $motor->fetch_assoc()) {
                        $res_tarif = $conn->query("SELECT harga FROM tarif WHERE motor_id={$row['id']} AND status='aktif' ORDER BY id DESC LIMIT 1");
                        $harga = $res_tarif->fetch_assoc()['harga'] ?? 0;
                    ?>
                        <option value="<?= $row['id'] ?>" data-harga="<?= $harga ?>">
                            <?= $row['merk'] ?> - <?= $row['plat_nomor'] ?> (Rp <?= number_format($harga) ?>)
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="input-group">
                <label>Tipe Durasi</label>
                <select name="tipe_durasi" id="tipe_durasi" required onchange="updateTotal()">
                    <option value="">-- Pilih Durasi --</option>
                    <option value="harian">Harian</option>
                    <option value="mingguan">Mingguan</option>
                    <option value="bulanan">Bulanan</option>
                </select>
            </div>

            <div class="input-group">
                <label>Tanggal Mulai</label>
                <input type="date" name="tanggal_mulai" id="tanggal_mulai" required onchange="updateTotal()">
            </div>

            <div class="input-group">
                <label>Tanggal Selesai</label>
                <input type="date" name="tanggal_kembali" id="tanggal_kembali" readonly>
            </div>

            <div class="input-group">
                <label>Jumlah (Rp)</label>
                <input type="number" name="jumlah" id="jumlah" readonly>
            </div>

            <div class="input-group">
                <label>Status</label>
                <select name="status" required>
                    <option value="Pending">Pending</option>
                    <option value="Lunas">Lunas</option>
                </select>
            </div>

            <button type="submit" name="simpan"><i class="fa fa-save"></i> Simpan Transaksi</button>
        </form>
    </div>
</div>

<script>
function updateTotal() {
    const motorSelect = document.getElementById('motor_id');
    const tipeDurasi = document.getElementById('tipe_durasi').value;
    const tanggalMulai = document.getElementById('tanggal_mulai').value;
    const jumlahInput = document.getElementById('jumlah');
    const tanggalKembali = document.getElementById('tanggal_kembali');

    if (!motorSelect.value || !tipeDurasi || !tanggalMulai) return;

    const harga = parseFloat(motorSelect.selectedOptions[0]?.dataset?.harga ?? 0);
    let selesai = new Date(tanggalMulai);

    if (tipeDurasi === 'harian') selesai.setDate(selesai.getDate() + 1);
    else if (tipeDurasi === 'mingguan') selesai.setDate(selesai.getDate() + 7);
    else if (tipeDurasi === 'bulanan') selesai.setMonth(selesai.getMonth() + 1);

    tanggalKembali.value = selesai.toISOString().split('T')[0];
    jumlahInput.value = harga;
}
</script>
</body>
</html>
