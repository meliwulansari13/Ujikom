<?php
require('fpdf/fpdf.php');
include "koneksi.php";

// Ambil filter periode dari URL, default bulan
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'bulan';

// Ambil data total pendapatan sesuai periode
if ($periode == 'hari') {
    $sql = "SELECT DATE(tanggal_bayar) AS periode, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY DATE(tanggal_bayar)
            ORDER BY DATE(tanggal_bayar) DESC";
} elseif ($periode == 'minggu') {
    $sql = "SELECT YEAR(tanggal_bayar) AS tahun, WEEK(tanggal_bayar, 1) AS minggu, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY YEAR(tanggal_bayar), WEEK(tanggal_bayar, 1)
            ORDER BY YEAR(tanggal_bayar) DESC, WEEK(tanggal_bayar,1) DESC";
} elseif ($periode == 'tahun') {
    $sql = "SELECT YEAR(tanggal_bayar) AS periode, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY YEAR(tanggal_bayar)
            ORDER BY YEAR(tanggal_bayar) DESC";
} else {
    $sql = "SELECT DATE_FORMAT(tanggal_bayar,'%Y-%m') AS periode, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY DATE_FORMAT(tanggal_bayar,'%Y-%m')
            ORDER BY DATE_FORMAT(tanggal_bayar,'%Y-%m') DESC";
}

$result = $conn->query($sql);

// Total keseluruhan
$total_keseluruhan = $conn->query("SELECT SUM(jumlah) AS total FROM pembayaran")->fetch_assoc()['total'] ?? 0;

// Inisialisasi PDF
$pdf = new FPDF('L','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Laporan Total Pendapatan',0,1,'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(200,200,200);
$pdf->Cell(20,8,'No',1,0,'C',true);
$pdf->Cell(80,8,'Periode',1,0,'C',true);
$pdf->Cell(40,8,'Total Pendapatan (Rp)',1,1,'C',true);

// Isi tabel
$pdf->SetFont('Arial','',10);
$i=1;
while($row = $result->fetch_assoc()){
    $label = ($periode=='minggu') ? "Tahun ".$row['tahun']." - Minggu ".$row['minggu'] : $row['periode'];
    $pdf->Cell(20,8,$i++,1,0,'C');
    $pdf->Cell(80,8,$label,1,0);
    $pdf->Cell(40,8,number_format($row['total'],0,',','.'),1,1,'R');
}

// Total keseluruhan
$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,8,'Total Keseluruhan',1,0,'R',true);
$pdf->Cell(40,8,number_format($total_keseluruhan,0,',','.'),1,1,'R',true);

// Output PDF
$pdf->Output('D','total_pendapatan.pdf');
