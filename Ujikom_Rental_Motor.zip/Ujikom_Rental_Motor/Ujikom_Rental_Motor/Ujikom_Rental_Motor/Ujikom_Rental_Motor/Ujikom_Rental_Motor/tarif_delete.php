<?php
include "koneksi.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: tarif.php");
    exit;
}

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, 
        "SELECT t.*, m.merk, m.tipe_cc, m.plat_nomor 
         FROM tarif t 
         JOIN motor m ON t.motor_id = m.id 
         WHERE t.id=$id"));

if (!$data) {
    header("Location: tarif.php");
    exit;
}

if (isset($_POST['hapus'])) {
    mysqli_query($conn, "DELETE FROM tarif WHERE id=$id");
    header("Location: tarif.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hapus Tarif</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: #f2f3f5;
        }
        .container {
            max-width: 500px;
            margin: 80px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
        }
        h2 {
            color: #e74c3c;
            margin-bottom: 20px;
        }
        p {
            font-size: 15px;
            margin-bottom: 25px;
            color: #555;
        }
        .btn {
            display: inline-block;
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 14px;
            text-decoration: none;
            margin: 0 8px;
            transition: 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        .btn-delete:hover {
            background: #c0392b;
        }
        .btn-cancel {
            background: #7f8c8d;
            color: white;
        }
        .btn-cancel:hover {
            background: #636e72;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2><i class="fa fa-trash"></i> Hapus Tarif</h2>
        <p>Apakah Anda yakin ingin menghapus tarif untuk motor:<br>
           <b><?= $data['merk'].' '.$data['tipe_cc'].' / '.$data['plat_nomor'] ?></b>?</p>
        <form method="post">
            <button type="submit" name="hapus" class="btn btn-delete">
                <i class="fa fa-check"></i> Ya, Hapus
            </button>
            <a href="tarif.php" class="btn btn-cancel">
                <i class="fa fa-times"></i> Batal
            </a>
        </form>
    </div>
</body>
</html>
