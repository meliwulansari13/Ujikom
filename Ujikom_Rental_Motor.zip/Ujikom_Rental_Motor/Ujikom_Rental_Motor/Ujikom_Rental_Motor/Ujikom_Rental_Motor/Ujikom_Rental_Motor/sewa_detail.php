<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

// Cek ID sewa
if (!isset($_GET['id'])) {
    header("Location: sewa.php");
    exit;
}
$id = (int)$_GET['id'];

// Ambil data sewa
$sql = "SELECT s.*, m.merk, m.tipe_cc, m.plat_nomor, u.nama AS penyewa,
        GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) AS lama_sewa,
        CASE s.tipe_durasi
            WHEN 'harian' THEN COALESCE(t_harga.tarif_harian,0)
            WHEN 'mingguan' THEN COALESCE(t_harga.tarif_mingguan,0)
            WHEN 'bulanan' THEN COALESCE(t_harga.tarif_bulanan,0)
        END AS harga_satuan,
        GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) *
        CASE s.tipe_durasi
            WHEN 'harian' THEN COALESCE(t_harga.tarif_harian,0)
            WHEN 'mingguan' THEN COALESCE(t_harga.tarif_mingguan,0)
            WHEN 'bulanan' THEN COALESCE(t_harga.tarif_bulanan,0)
        END AS total_harga
    FROM sewa s
    JOIN motor m ON s.motor_id = m.id
    JOIN users u ON s.penyewa_id = u.id
    LEFT JOIN (
        SELECT motor_id,
               MAX(CASE WHEN jenis='harian' THEN harga END) AS tarif_harian,
               MAX(CASE WHEN jenis='mingguan' THEN harga END) AS tarif_mingguan,
               MAX(CASE WHEN jenis='bulanan' THEN harga END) AS tarif_bulanan
        FROM tarif
        WHERE status='aktif'
        GROUP BY motor_id
    ) t_harga ON t_harga.motor_id = m.id
    WHERE s.id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<p>Data penyewaan tidak ditemukan.</p>";
    exit;
}
$data = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Detail Penyewaan</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{margin:0;font-family:'Segoe UI',sans-serif;background:#f4f6f9;}
.container{max-width:800px;margin:30px auto;background:white;padding:25px;border-radius:12px;box-shadow:0 4px 10px rgba(0,0,0,0.1);}
h2{margin-top:0;color:#34495e;}
.detail{margin-top:20px;}
.detail p{margin:8px 0;font-size:15px;}
.label{font-weight:bold;color:#555;}
.actions{margin-top:25px;display:flex;gap:10px;}
.actions a{padding:10px 16px;border-radius:6px;color:white;text-decoration:none;display:inline-block;font-size:14px;}
.btn-back{background:#7f8c8d;} .btn-back:hover{background:#616d70;}
.btn-edit{background:#17a2b8;} .btn-edit:hover{background:#138496;}
.btn-delete{background:#dc3545;} .btn-delete:hover{background:#b02a37;}
</style>
</head>
<body>
<div class="container">
    <h2>Detail Penyewaan</h2>
    <div class="detail">
        <p><span class="label">Motor:</span> <?= htmlspecialchars($data['merk'].' '.$data['tipe_cc'].' / '.$data['plat_nomor']) ?></p>
        <p><span class="label">Penyewa:</span> <?= htmlspecialchars($data['penyewa']) ?></p>
        <p><span class="label">Tanggal Mulai:</span> <?= $data['tanggal_mulai'] ?></p>
        <p><span class="label">Tanggal Selesai:</span> <?= $data['tanggal_selesai'] ?></p>
        <p><span class="label">Lama Sewa:</span> <?= $data['lama_sewa'] ?> hari</p>
        <p><span class="label">Tipe Durasi:</span> <?= ucfirst($data['tipe_durasi']) ?></p>
        <p><span class="label">Harga Satuan:</span> Rp <?= number_format($data['harga_satuan'],0,',','.') ?></p>
        <p><span class="label">Total Harga:</span> Rp <?= number_format($data['total_harga'],0,',','.') ?></p>
        <p><span class="label">Status:</span> <?= ucfirst($data['status']) ?></p>
    </div>

    <div class="actions">
        <a href="sewa.php" class="btn-back"><i class="fa fa-arrow-left"></i> Kembali</a>
        <a href="sewa_edit.php?id=<?= $data['id'] ?>" class="btn-edit"><i class="fa fa-edit"></i> Edit</a>
        <a href="sewa_delete.php?id=<?= $data['id'] ?>" class="btn-delete" onclick="return confirm('Yakin hapus penyewaan ini?')"><i class="fa fa-trash"></i> Hapus</a>
    </div>
</div>
</body>
</html>
